#include <stdio.h>
#include <locale.h>
int main (){
	setlocale(LC_ALL, "Portuguese");
	 int idade,cont = 0,qtd,qtda = 0,qtdp = 0,qtdv = 0,qtdc = 0,qtdo = 0;
	 char cor;
	 printf ("Insira a quantidade de pessoas: ");
	 scanf ("%d", &qtd);
	 
	 while (cont < qtd){
	 	printf ("Insira a %d idade: " ,cont + 1);
	 	scanf ("%d", &idade);
	 	fflush (stdin);
	 	printf ("Insira a %d cor de olho: ", cont + 1);
	 	scanf (" %c", &cor);
	 	
	 	if (cor == 'A'){
	 	qtda+=1;
	 	printf ("%d", qtda);
		 }
		if (cor == 'P'){
	 	qtdp+=1;
		 }
		if (cor == 'V'){
	 	qtdv+=1;
		 }
			if (cor == 'C'){
	 	qtdc+=1;
		 }
		 	if (cor == 'O'){
	 	qtdo+=1;
		 }  
	 	cont++;
	 }
	 printf ("Cor azul: %d", qtda);
	 printf ("\nCor preto: %d", qtdp);
	 printf ("\nCor verde: %d", qtdv);
	 printf ("\nCor castanho: %d", qtdc);
	 printf ("\nOutra cor: %d", qtdo);
	 
	return 0;
}
