#include <stdio.h>
#include <locale.h>
int main (){
setlocale(LC_ALL, "Portuguese");

   int valor,cont = 1,soma = 0;
   float media;
   while (cont <= 5){
    printf ("Digite o %d valor: ", cont);
    scanf ("%d", &valor);
    soma = soma + valor;
    cont ++;
   }
   printf ("\nA m�dia � %.2f", (float)soma/cont);
return 0;
}
