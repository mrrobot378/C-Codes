#include <stdio.h>
#include <locale.h>
int main (){
setlocale(LC_ALL, "Portuguese");

   int num,num2,n;
   printf ("Digite o primeiro valor: ");
   scanf ("%d", &num);
   printf ("Digite o segundo valor: ");
   scanf ("%d", &num2);
   printf ("\nMENU\n 1- Somar os dois n�meros\n 2- Subtrair os n�meros\n 3- Multiplicar os dois n�meros\n 4- Dividir os dois n�meros (o denominador n�o pode ser zero) \n 5- Sair");
   printf ("\n\nDigite a o op��o desejada: ");
   scanf ("%d", &n);
   switch (n){
case 1:
    printf ("%d", num + num2);
    break;
case 2:
    printf ("%d", num - num2);
    break;
case 3:
    printf ("%d", num * num2);
    break;
case 4:
    printf ("%d", num / num2);
    break;
default:
    break;
   }
return 0;
}
