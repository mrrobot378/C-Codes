#include <stdio.h>
#include <locale.h>
int main ()
{setlocale(LC_ALL, "Portuguese");

    int numeros[100],qtd,num;
    
    printf ("Diga a quantidade de valores:\n");
    scanf ("%d", &qtd);
    for (int i = 0; i < qtd; i++){
  	scanf ("%d", &numeros[i]);
    }
    
    printf ("\nInsira o valor para verificar se est� entre os digitados:\n");
    scanf ("%d", &num);
    
    for (int i = 0; i < qtd; i++){
    	
    if (num == numeros[i])
	{
    
    printf ("\nO n�mero %d est� no vetor", num);
		break;
	}
	
    }
    if (num != numeros[i])
	{
    
    printf ("\nO n�mero %d n�o est� no vetor", num);
		break;
	}
	return 0;
}
