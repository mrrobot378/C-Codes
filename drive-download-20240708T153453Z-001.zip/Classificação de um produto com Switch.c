#include <stdio.h>
#include <locale.h>
int main (){
setlocale(LC_ALL, "Portuguese");

   int cod;
   printf ("Digite o c�digo do produto: ");
   scanf ("%d", &cod);
   switch (cod){
   case 1:
    printf ("Alimento n�o-perec�vel");
    break;
   case 4:
   case 2 ... 3:
    printf ("Alimento perec�vel");
    break;
    case 5 ... 6:
     printf ("Vestu�rio");
     break;
     case 7:
     printf ("Higiene Pessoal");
     break;
     case 8 ... 15:
     printf ("Limpeza e Utens�lios Dom�sticos");
     break;
   default:
     printf ("Inv�lido");
     break;
   }
return 0;
}
