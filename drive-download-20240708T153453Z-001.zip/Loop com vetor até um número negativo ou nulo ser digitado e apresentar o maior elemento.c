#include <stdio.h>
#include <locale.h>
int main ()
{setlocale(LC_ALL, "Portuguese");

    int numeros[100],maior = 0;
    printf ("Insira valores e quando quiser parar, insira um negativo ou 0!\n");
    for (int i = 0; i < 100; i++){
  	scanf ("%d", &numeros[i]);
  	
  	if (numeros[i] > maior)
	  {
	  maior = numeros[i];	
	  }
	  
  	if (numeros[i] <= 0)
  	{
  		break;
	  }
  	
    }
    printf ("Maior elemento inserido: %d", maior);
	return 0;
}
