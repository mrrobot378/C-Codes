#include <stdio.h>
#include <math.h>

int soma(int a, int b){
	int soma = a + b;
	return soma;
}

int main() {
	int x,y,r;
	scanf ("%d", &x);
	scanf ("%d", &y);
	r = soma(x,y);
	printf ("%d", r);

	return 0;
}
