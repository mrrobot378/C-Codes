#include <stdio.h>
#include <math.h>

int main() {
    int numeros[5],i = 0;
    for (int cont = 0; cont < 5; cont++){
    	scanf ("%d", &numeros[i]);
    	i++;
	}
    printf ("Posi��o 0: %d",numeros[0]);
    printf ("Posi��o 1: %d",numeros[1]);
    printf ("Posi��o 2: %d",numeros[2]);
    printf ("Posi��o 3: %d",numeros[3]);
    printf ("Posi��o 4: %d",numeros[4]);
    return 0;
}
