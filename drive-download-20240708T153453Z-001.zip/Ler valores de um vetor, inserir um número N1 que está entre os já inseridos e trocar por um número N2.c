#include <stdio.h>
#include <locale.h>
int main ()
{setlocale(LC_ALL, "Portuguese");

    int numeros[100],qtd,num1,num2;
    
    printf ("Diga a quantidade de valores:\n");
    scanf ("%d", &qtd);
   
   //armazenar os valores no vetor 
    for (int i = 0; i < qtd; i++){
  	scanf ("%d", &numeros[i]);
    }
    
    //digitar um n�mero N1 que foi inserido, para ser trocado por N2
    printf ("\nInsira o valor N1:\n");
    scanf ("%d", &num1);
    
    //digitar o N2
    printf ("\nInsira o valor N2:\n");
    scanf ("%d", &num2);
    
    //percorre todo o vetor e verifica se N1 est� nos valores
    //inseridos e faz a troca de N1 por N2
    for (int i = 0; i < qtd; i++){
    	
    if (num1 == numeros[i])
	{

    numeros[i] = num1 = num2;
		
	}
	
    }
    
    //mostrar a lista de n�meros com os n�meros trocados
    for (int i = 0; i < qtd; i++){
  	printf ("%d", numeros[i]);
    }
	return 0;
}
