#include <stdio.h>
#include <locale.h>
int main (){
setlocale(LC_ALL, "Portuguese");

   char letra;
   printf ("Digite a letra: ");
   scanf ("%c", &letra);
   switch (letra){
   case 'a':
   case 'e':
   case 'i':
   case 'o':
   case 'u':
    printf ("� uma vogal!");
    break;
   default:
     printf ("� uma consoante!");
     break;
   }
return 0;
}
