#include <stdio.h>
#include <locale.h>
int main (){
setlocale(LC_ALL, "Portuguese");

   int cod,qtd;
   printf ("Digite o c�digo do item: ");
   scanf ("%d", &cod);
   printf ("Digite a quantidade desse item: ");
   scanf ("%d", &qtd);
   switch (cod){
   case 100:
    printf ("Pre�o a Pagar: R$ %d", 7 * qtd);
    break;
   case 101:
    printf ("Pre�o a Pagar: R$ %d", 5 * qtd);
    break;
    case 102:
     printf ("Pre�o a Pagar: R$ %d", 10 * qtd);
     break;
     case 103:
     printf ("Pre�o a Pagar: R$ %d", 12 * qtd);
     break;
     case 104:
     printf ("Pre�o a Pagar: R$ %d", 3 * qtd);
     break;
   default:
     printf ("\nItem n�o encontrado!");
     break;
   }
return 0;
}
