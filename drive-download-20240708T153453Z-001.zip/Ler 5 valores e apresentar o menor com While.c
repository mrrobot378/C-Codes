#include <stdio.h>
#include <locale.h>
int main (){
   setlocale (LC_ALL, "Portuguese");
   int valor, cont = 0,qpar = 0,qim = 0;

   //Para ter uma inser��o de valores n�o
   //definidos, fazemos o num != do valor
   //"encerrador" do programa

   while (valor != 0){
    printf ("Insira o %d valor: ", cont + 1);
    scanf ("%d", &valor);
    if (valor % 2 == 0 && valor != 0){
        qpar = qpar + 1;
    } if (valor % 2 != 0 && valor != 0){
     qim = qim + 1;
    }
    cont++;
   }

    printf ("Quantidade de pares: %d", qpar);
    printf ("\nQuantidade de �mpares: %d", qim);
   return 0;
}
