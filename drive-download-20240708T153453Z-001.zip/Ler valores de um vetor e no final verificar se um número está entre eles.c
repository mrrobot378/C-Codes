#include <stdio.h>
#include <locale.h>
int main ()
{setlocale(LC_ALL, "Portuguese");

    int numeros[100],qtd,num1,num2;
    
    printf ("Diga a quantidade de valores:\n");
    scanf ("%d", &qtd);
    for (int i = 0; i < qtd; i++){
  	scanf ("%d", &numeros[i]);
    }
    
    printf ("\nInsira o valor N1:\n");
    scanf ("%d", &num1);
    
    printf ("\nInsira o valor N2:\n");
    scanf ("%d", &num2);
    
    for (int i = 0; i < qtd; i++){
    	
    if (num1 == numeros[i])
	{

    numeros[i] = num1 = num2;
		
	}
	
    }
    for (int i = 0; i < qtd; i++){
  	printf ("%d", numeros[i]);
    }
	return 0;
}
