#include <stdio.h>
#include <locale.h>
#include <string.h>
int main ()
{ setlocale(LC_ALL, "Portuguese");

    int tamanho,chave;
    char palavra[100],aux[100];
    printf ("Digite a palavra: ");
    gets(palavra);
    strcpy (aux,palavra);

    printf ("\nDigite a chave [0,10]: ");
    scanf ("%d", &chave);

    tamanho = strlen (palavra);

    for (int i = 0; i < tamanho; i++)
    {
        palavra[i] = aux[i] + chave;
    }

    printf ("Palavra Codificada: %s", palavra);

    for (int i = 0; i < tamanho; i++)
    {
        palavra[i] = aux[i] - chave;
    }
    printf ("\nPalavra Decodificada: %s", palavra);


   return 0;
}
