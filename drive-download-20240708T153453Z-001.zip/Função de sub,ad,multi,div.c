#include <stdio.h>
#include <math.h>
#include <locale.h>

//fun��o feita para adi��o de dois valores
    int ad(int a,int b){
	int adicao = a + b;
	return adicao;
	}	
	
//fun��o feita para subtr��o de dois valores	
	int sub(int a, int b){
	int sub = a - b;
	return sub;
    }

//fun��o feita para multiplicar dois valores
    int mult(int a,int b){
	int mult = a * b;
	return mult;
	}
	
//fun��o feita para dividir dois valores 
    float div(float a,float b){
     float div = (float) a/b;
    	return div;
	}	

int main (){
	setlocale(LC_ALL, "Portuguese");
	
	//var de ad
	int num1,num2,r;
	//var de sub
	int valor1,valor2,re;
	//var de mult
	int n1,n2,res;
	//var de div
	float v1,v2;
	float resul;
	
//ad
	scanf ("%d", &num1);
	scanf ("%d", &num2);
	r = ad(num1,num2);
	printf ("Adi��o : %d\n", r);
	
//sub
    scanf ("%d", &valor1);
	scanf ("%d", &valor2);
	re = sub(valor1,valor2);
	printf ("Subtra��o: %d\n", re);
	
//mult
    scanf ("%d", &n1);
	scanf ("%d", &n2);
	res = mult(n1,n2);
	printf ("Multiplica��o: %d\n", res);	
	
//div
	scanf ("%d", &v1);
	scanf ("%d", &v2);
	resul = div(v1,v2);
	printf ("Divis�o : %.2f\n", resul);
	return 0;
}

