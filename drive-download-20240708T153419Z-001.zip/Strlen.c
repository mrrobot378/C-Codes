#include <stdio.h>
int main (){
  char tamanho[90];
  gets (tamanho);
  int comprimento = strlen(tamanho);
  printf ("%d", comprimento);
return 0;
}
