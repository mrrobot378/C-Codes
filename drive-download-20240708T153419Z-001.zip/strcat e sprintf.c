#include <stdio.h>
int main (){
  char nome[90],sobrenome[90];
  char nomecompleto[90]=" ";
  gets (nome);
  gets (sobrenome);
  sprintf (nomecompleto,"%s" " " "%s", nome,sobrenome);
  printf("Nome completo: %s\n",nomecompleto);
return 0;
}
