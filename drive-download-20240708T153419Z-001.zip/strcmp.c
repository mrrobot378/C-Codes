#include <stdio.h>
int main (){
  char amigo1[60],amigo2[60];
  gets (amigo1);
  gets (amigo2);
  int comparacao = strcmp(amigo1,amigo2);
  printf ("%d", comparacao);
return 0;
}
