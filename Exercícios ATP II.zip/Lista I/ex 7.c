#include <stdio.h>

int main()
{
    float array[6], soma = 0, media, qtd;
    
    for (int i = 0; i < 6; i++)
    {
        scanf ("%f", &array[i]);
        soma = array[i] + soma;
    }
    
    media = soma/6;

   printf ("\nResultado da m�dia: %.2f", media);
    
    
    return 0;
}
