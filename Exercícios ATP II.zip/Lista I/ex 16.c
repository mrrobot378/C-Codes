/*
  Escreva um programa em C que declare um array de 10
  caracteres e use um ponteiro para contar quantos desses caracteres s�o letras
  mai�sculas.
*/

#include <stdio.h>

int main()
{
    char array[10];
    
    int cont = 0;
    
    scanf ("%s", array);
    
    char *p;
    
    p = array;
    
    for (int i = 0; i < 10; i++)
    {
        if (p[i] >= 65 && p[i] <= 90)
        {
            cont += 1;
        }
    }
    
    printf ("A quantidade de mai�sculas s�o: %d", cont);

    return 0;
}
