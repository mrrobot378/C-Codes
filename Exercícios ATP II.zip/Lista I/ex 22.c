#include <stdio.h>
#include <stdlib.h>
/*
  Escreva um programa em C que conte o n �umero de elementos
pares e  �impares em um array de 20 inteiros.
*/


int main()
{
    int array[20], pares = 0, impares = 0;

    for (int i = 0; i < 20;i++) 
    {
        array[i] += i; // preenchendo com valores de 0 a 19 no array
        
        if (array[i] % 2 != 0) //verificando quantos s�o pares
        {
            pares += 1;
        }else //verificando quantos s�o �mpares
       {
           impares += 1;
       }
        
        
    }

    printf ("\nQuantidades de pares: %d", pares);
    printf ("\nQuantidades de �mpares: %d", impares);

    return 0;
}
