/*
Escreva um programa em C que leia uma string e verifique
se ela �e um pal�ndromo.
*/

#include <stdio.h>
#include <string.h>

int main()
{
    char string[40];
    int tamanho,ehpalindromo; 
    
    
    scanf("%s", string);
    
    tamanho = strlen(string) - 1;
    
    for(int i = 0; i < tamanho; i++) //verificando se cada caracter � igual 
    {
        if (string[i] == string[tamanho])
        {
            ehpalindromo = 1;
        }else 
        {
            ehpalindromo = 0;  
        }
        tamanho--;
    }

     if (ehpalindromo == 1) //estrutura de decis�o para ver se � pal�ndromo
     {
         printf ("� um pal�ndromo!");
     }else if (ehpalindromo == 0)
     {
         printf ("N�o � um pal�ndromo!");
     }

    return 0;
}
