#include <stdio.h>

int main()
{
    int array[15],arrayp[7];

    for (int i = 1; i < 15; i++)
    {
        array[i] = i;
        if (array[i] %2 != 0  )
        {
            arrayp[i] = array[i];
            printf ("\n%d", arrayp[i]);
        }
    }
    
    return 0;
}
