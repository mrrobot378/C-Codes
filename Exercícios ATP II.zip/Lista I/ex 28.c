/*
  Escreva um programa em C que leia uma string e substitua
todas as ocorr�ncias de um caractere por outro.
*/

#include <stdio.h>

int main()
{
    char str[40],caractere;
    
    printf("Insira a string:");
    scanf ("\n%s", str);
    printf ("Insira o caractere voc� quer que seja substituido na frase:");
    scanf ("\n%c", &caractere);
    
    for (int i = 0; i < 40; i++)
    {
     if (str[i] == caractere)
     {
         str[i] = 'i';
     }
    }

    printf ("\n%s", str);

    return 0;
}
