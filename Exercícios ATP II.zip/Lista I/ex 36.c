#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

/*
  Escreva um programa em C que receba 5 n�meros inteiros
  como argumentos na linha de comando e imprima o maior deles.
*/

int main (int argc, char **argv)
{
    int maior = INT_MIN;
    
    for (int i = 1; i < 6; i++)
    {
    	if (atoi(argv[i]) > maior)
    	{
    		maior = atoi(argv[i]);
		}
	}
	
	printf("O maior elemento: %d", maior);
	
return 0;	
}
