#include <stdio.h>
#include <string.h>

/*
Escreva um programa em C que leia duas strings e concatene-
as. Imprima a string resultante.
*/

int main()
{
    char str1[50], str2[50], strc[100];
    int i = 0, j = 0;

    // Ler a primeira string
    scanf("%s", str1);

    // Ler a segunda string
    scanf("%s", str2);

    // Copiar a primeira string para strc
    while (str1[i] != '\0') {
        strc[i] = str1[i];
        i++;
    }

    // Concatenar a segunda string em strc
    while (str2[j] != '\0') {
        strc[i] = str2[j];
        i++;
        j++;
    }

    // Adicionar o caractere nulo no final
    strc[i] = '\0';

    // Imprimir a string concatenada
    printf("%s\n", strc);

    return 0;
}
