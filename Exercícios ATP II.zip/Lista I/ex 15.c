/*
  Escreva um programa em C que declare um array de 7
inteiros e use um ponteiro para calcular a soma dos elementos do array.
*/

int main() {
    int meuVetor[7] = {1, 2, 3, 4, 5, 6, 7};
    int *p;
    int soma = 0;
    
    for(int i = 0; i < 7; i++)
    {
        p = &meuVetor[0 + i];
        soma += *p;
    }
    
    printf("A soma �: %d", soma);
    
    return 0;
}
