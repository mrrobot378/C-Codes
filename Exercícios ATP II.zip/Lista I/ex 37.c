#include <stdio.h>

/*
 Escreva um programa em C que declare um array de 5 inteiros
e passe esse array para uma fun��o que calcule a m�dia dos elementos do array.
*/

#include <stdio.h>
#include <locale.h>
// Fun��o que calcula a m�dia dos elementos de um array
float media(float arry[]) {
    float s = 0;
    for (int i = 0; i < 5; i++) {
        s += arry[i];
    }
    return s / 5;
}

int main() {
	
	setlocale(LC_ALL, "Portuguese");
	
    float array[5];
    float res;

    printf("Digite 5 n�meros:\n");
    for (int i = 0; i < 5; i++) {
        scanf("%f", &array[i]);
    }

    res = media(array);

    printf("A m�dia �: %.2f\n", res);

    return 0;
}

