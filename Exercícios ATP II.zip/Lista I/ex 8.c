#include <stdio.h>

int main() {
    char caracteres[8];
    int vogais = 0;

    printf("Digite 8 caracteres:\n");
    for (int i = 0; i < 8; i++) {
        scanf(" %c", &caracteres[i]);
        
        if (caracteres[i] == 'a' || caracteres[i] == 'e' || caracteres[i] == 'i' || caracteres[i] == 'o' || caracteres[i] == 'u' ||
            caracteres[i] == 'A' || caracteres[i] == 'E' || caracteres[i] == 'I' || caracteres[i] == 'O' || caracteres[i] == 'U') 
        {
            vogais++;
        }
    }

    printf("N�mero de vogais: %d\n", vogais);

    return 0;
}
