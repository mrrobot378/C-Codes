/*
  Escreva um programa em C que use um array de ponteiros para
armazenar e imprimir 5 strings.
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char *vetor[5];
    
    for (int i = 0; i < 5; i++) { //alocando memória para 5 strings
    vetor[i] = malloc(101 * sizeof(char)); // 100 caracteres + 1 para o terminador nulo
}
 
 for (int i = 0; i < 5; i++) //armazenando cada string em um endereço
 {
     scanf("\n%s", vetor[i]);
 }
 
    for (int i = 0; i < 5; i++) { //mostrando cada string em determinados endereços (com i de parâmetro)
    printf("%s\n", vetor[i]);
}

    for (int i = 0; i < 5; i++) { //liberando o hipe
    free(vetor[i]);
}

    

    return 0;
}
