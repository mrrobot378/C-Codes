#include <stdio.h>

int main()
    {
        srand (time(0));
        
        int array[20];
        
      for (int i = 0; i < 20;i++)
      {
          array[i] = rand() % 100;
      }
      
       
      for (int i = 0; i < 20;i++)
      {
         printf("\n%d", array[i]);
      }

    return 0;
}
