#include <stdio.h>

/*
    Escreva um programa em C que declare um array de 5
inteiros e um ponteiro para inteiro. Use o ponteiro para modificar os valores
dos elementos do array. Imprima o array resultante.
*/

int main()
{
    int *p1, array[5];
    
    array[0] = 1;
    array[1] = 2;
    array[2] = 3;
    array[3] = 4;
    array[4] = 5;
    
    p1 = &array;
    
    for (int i = 0; i < 5; i++)
    {
        p1[i] += 5;
        printf("\n%d", p1[i]);
    }
    
    
    return 0;
}
