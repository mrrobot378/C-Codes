#include <stdio.h>
#include<stdlib.h>
#include <locale.h>

/*
  Escreva um programa em C que declare um array de 12
  caracteres e use aritm�tica de ponteiros para inverter a ordem dos caracteres no
  array.
*/

int main ()
{
	char c[12] = "Paralelogra";
	char *p;
	char aux[6];
	
	p = c;
	
	for (int i = 0; i < 6; i++)
	{
		aux[i] = p[i];
		c[i] = c[10 - i];
		c[10 - i] = aux[i];
		
	}
	
    printf("String invertida: %s", c);
	
	return 0;
}
