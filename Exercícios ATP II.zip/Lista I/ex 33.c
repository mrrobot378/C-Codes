#include <stdio.h>

int main(int argc, char **argv)
{
int soma = 0, aux = 0;

    for(int i = 1; i < 4; i++)
    {
        aux = atoi(argv[i]);
        soma += aux;
    }

    printf("Soma: %d, ARGC: %d", soma, argc);

}

