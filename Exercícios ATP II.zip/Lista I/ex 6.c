#include <stdio.h>

int main()
{
    int array[10], soma = 0;
    
    for (int i = 0; i < 10; i++)
    {
        scanf ("%d", &array[i]);
        soma = array[i] + soma;
    }


   printf ("\nResultado da soma: %d", soma);
    
    
    return 0;
}
