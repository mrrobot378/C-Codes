#include <stdio.h>

int main() {
    // Declarando o array de 8 n�meros de ponto flutuante
    double fibonacci[8];

    // Inicializando os primeiros 8 n�meros da sequ�ncia de Fibonacci
    fibonacci[0] = 0.0;
    fibonacci[1] = 1.0;
    for (int i = 2; i < 8; i++) {
        fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
    }

    // Imprimindo todos os elementos do array
    printf("Sequ�ncia de Fibonacci:\n");
    for (int i = 0; i < 8; i++) {
        printf("%.2lf ", fibonacci[i]);
    }
    printf("\n");

    return 0;
}
