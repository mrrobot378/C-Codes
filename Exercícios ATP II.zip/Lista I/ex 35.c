#include <stdio.h>

/*
 Escreva um programa em C que receba um n�mero inteiro
 como argumento na linha de comando e verifique se ele � par ou �mpar.
*/

int main (int argc, char **argv)
{
    if(atoi(argv[1]) % 2 == 0)
    {
    	printf("Numero par!");
	}else if(atoi(argv[1]) % 2 != 0)
    {
    	printf("Numero impar!");
	}
	
	
return 0;	
}
