#include <stdio.h>
#include<stdlib.h>
#include <locale.h>

/*
 Escreva um programa em C que declare um array de 10
 inteiros e use aritm�tica de ponteiros para calcular a soma de todos os
 elementos do array. Imprima a soma.
*/

int main ()
{
	int array[5] = {1,2,3,4,5} , soma = 0;
	int *p;
	
	p = array;	
  
    for (int i = 0; i < 5; i++)
    {
    	soma += p[i];
	}

    printf ("A soma �: %d", soma);
	
	return 0;
}
