/*
  Escreva um programa em C que use um array de ponteiros
  para armazenar 5 n�meros inteiros e encontre o maior valor entre eles.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int main()
{
   int *vet[5]; //declarando um array de ponteiros de 5 n�meros
   
   int maior = INT_MIN;
   
   for (int i = 0; i < 5; i++) //alocando mem�ria para os 5 n�meros
   {
       vet[i] = malloc(sizeof(int));
   }
   
   for (int i = 0; i < 5; i++) 
   {
       scanf("%d", vet[i]);
   }
   
   for(int i = 0; i < 5; i++) //verificando qual o maior
   {
       if (*vet[i] > maior)
       {
           maior = *vet[i];
       }
   }

   printf("O maior elemento �: %d", maior);
   
   // Libera��o da mem�ria alocada
    for (int i = 0; i < 5; i++)
    {
        free(vet[i]);
    }
    return 0;
}
