#include <stdio.h>

/*
  Escreva um programa em C que encontre o maior e o menor
  elemento em um array de 10 inteiros.
*/


int main()
{
    int array[10], maior = 0, menor = 1234324;

    for (int i = 0; i < 10;i++) // loop criado para preencher o array de 0 a 9
    {
        array[i] += i;
        
        if (array[i] > maior) //verificando qual o maior n�mero
        {
            maior = array[i];
        }
        
       if (array[i] < menor) //verificando qual o menor n�mero
       {
           menor = array[i];
       }
        
        
    }

    printf ("\nMaior elemento: %d", maior);
    printf ("\nMenor elemento: %d", menor);

    return 0;
}
