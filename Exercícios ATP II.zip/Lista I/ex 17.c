/*
  Escreva um programa em C que declare um array de 5 inteiros
  e use aritm�tica de ponteiros para somar 10 a cada elemento do array. Imprima
  o array resultante.
*/

#include <stdio.h>

int main()
{
    int array[5] = {1, 2, 3, 4, 5};
    
    int *p;
    
    p = array;
    
    for (int i = 0; i < 5; i++)
    {
        printf("%d\t",p[i] += 10);
    }

    return 0;
}
