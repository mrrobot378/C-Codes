 /*
   Escreva um programa em C que leia uma string e conte o n�mero
   de caracteres, palavras e linhas na string.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{   
    int contp = 1,
        contc = 0; //contc = contador de caracteres
    
    char string[50];
    
    scanf ("%s", string);
    
    for (int i = 0; i < 50; i++)
    {
        if(string[i] == '\0')
        {
            break;
        }
        
        if (   (string[i] >= 65 && string[i] <= 90) 
            || (string[i] >= 97 && string[i] <= 122) 
            || (string[i] == '-')
           )
        {
            contc += 1;  //contc = contador de caracteres
        }
        
        else
        {
            printf ("\n NAO \n %c,%d",string[i], contc);
        }
        printf ("\n%d", contc);
    }
    
    for (int i = 0;i < 50;i++)
    {
        if (string[i] == '-')
        {
            contp += 1; //contp = contador de palavras
        }
    }
    
    printf ("\nQuantidade de palavras: %d", contp);
    printf ("\nQuantidade de caracteres: %d", contc);
    printf ("\nQuantidade de linhas: 1");
    

    return 0;
}
