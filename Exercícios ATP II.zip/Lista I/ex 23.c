#include <stdio.h>
#include <stdlib.h>
/*
  Escreva um programa em C que determine se um array de
  10 inteiros � sim�trico (um pal�ndromo).
*/

int main() {
    int array[10];
    int i;
    int ehPalindromo = 1; // Vari�vel para verificar se � pal�ndromo

    // Preenchendo com elementos o array
    printf("Digite 10 n�meros inteiros:\n");
    for (i = 0; i < 10; i++) {
        scanf("%d", &array[i]);
    }

    // Verifica��o se o array � um pal�ndromo
    for (i = 0; i < 5; i++) 
	{ 
	    // S� precisa verificar at� a metade
        if (array[i] != array[9 - i]) 
		{ // Compara os elementos do in�cio e do fim
            ehPalindromo = 0; // Se encontrar uma diferen�a, n�o � pal�ndromo
            break; // Sai do loop
        }
    }

    // Resultado
    if (ehPalindromo) {
        printf("\nO array � um pal�ndromo.");
    } else {
        printf("\nO array n�o � um pal�ndromo.");
    }

    return 0;
}
