#include <stdio.h>
#include <stdlib.h>
int main()
    {
        srand (time(0));
        
        int array[10],soma = 0;
        float media;
        
      for (int i = 0; i < 10;i++)
      {
          array[i] = rand() % 100 + 50;
          soma = array[i] + soma;
      }
     
     media = soma / 10;  
       
      printf ("%.2f", media);

    return 0;
}
