#include <stdio.h>
#include <stdlib.h>
int main()
    {
        srand (time(0));
        
        int array[15],maior = 0;
    
        
      for (int i = 0; i < 15;i++)
      {
          array[i] = rand() % 50;
          printf ("\n%d", array[i]); //verificando os elementos do array para ter certeza
          //que � o maior
          if (array [i] > maior)
          {
              maior = array[i];
          }
      }
     
     
       
      printf ("O maior: %d", maior);

    return 0;
}
