/*
  Escreva um programa em C que use um array de ponteiros
 para armazenar 4 strings e encontre a string de maior comprimento.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int main()
{
   char *vet[4],maior[61]; //declarando um array de ponteiros de 4 strings
   
   
   for (int i = 0; i < 4; i++) //alocando mem�ria para as 4 strings
   {
       vet[i] = malloc(61 * sizeof(char));
   }
   
   for (int i = 0; i < 4; i++) 
   {
       scanf("%s", vet[i]);
   }
   
   for(int i = 0; i < 4; i++) //verificando qual o de maior comprimento
   {
       if (strlen(vet[i]) > strlen(maior))
       {
           strcpy(maior,vet[i]);
       }
   }

   printf("A maior string �: %s", maior);
   
   // Libera��o da mem�ria alocada
    for (int i = 0; i < 4; i++)
    {
        free(vet[i]);
    }
    return 0;
}
