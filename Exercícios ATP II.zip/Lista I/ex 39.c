#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
/*
 Escreva um programa em C que declare um array de 6
 inteiros e passe esse array para uma fun��o que conte quantos elementos s�o
 positivos.
*/

  int contador(int arr[])
  {
  	int cont = 0;
  	
  	for (int i = 0; i < 6; i++)
  	{
  	   if(arr[i] > 0)
		{
		   cont += 1;	
		}	
	}
  	
  }

int main ()
{
	setlocale(LC_ALL, "Portuguese");
	
	int array[6],res;
	
	printf("Digite os 6 valores e veremos quantos s�o positivos:\n");
	for (int i = 0; i < 6; i++)
	{
		scanf ("%d", &array[i]);
	}
	
	res = contador(array);
	
	printf ("O n�mero de positivos s�o: %d", res);
	
return 0;	
}
