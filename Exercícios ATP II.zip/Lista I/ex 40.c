#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
/*
 Escreva um programa em C que declare um array de 8
 inteiros e passe esse array para uma fun��o que inverta a ordem dos elementos
 do array.
*/

  void invertor(int arr[], int invertido[])
  {
  for (int i = 0; i < 8; i++) {
        invertido[i] = arr[7 - i];
    }
  }	
  

int main ()
{
	setlocale(LC_ALL, "Portuguese");
	
	int array[8],invertido[8];
	
	printf("Digite os 8 valores e veremos sua ordem invertida:\n");
	for (int i = 0; i < 8; i++)
	{
		scanf ("%d", &array[i]);
	}
	
	invertor(array, invertido);
	
	printf("A ordem invertida �:");
	for (int i = 0; i < 8; i++)
	{
		printf ("%d\t", invertido[i]);
	}
	
	
return 0;	
}
