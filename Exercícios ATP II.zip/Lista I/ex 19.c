#include <stdio.h>
#include <stdlib.h>

/*
 Escreva um programa em C que declare um array de 8
n �umeros de ponto flutuante e use aritm �etica de ponteiros para calcular a m �edia
dos valores.
*/

int main()
{
    int soma = 0;
    float *p, array[8],media;
    
    //n�o usei "for" pois reaproveitei c�digos dos exerc�cios anteriores
    array[0] = 1;
    array[1] = 2;
    array[2] = 3;
    array[3] = 4;
    array[4] = 5;
    array[5] = 6;
    array[6] = 7;
    array[7] = 8;
    

    p = &array;
    
    printf ("M�DIA:");
    
    for (int i = 0; i < 8; i++) //realizando a soma dos elementos para 
    //usar posteriormente na m�dia
    
    {
        
        soma += p[i];
        printf ("\n%d", soma);
    }
        media = soma/8;    
        printf ("\n%.2f", media);
        
    return 0;
}
