/*
 Escreva um programa em C que declare um array de 10
 inteiros e passe esse array para uma fun��o que encontre o maior elemento do
 array.
*/

#include <stdio.h>
#include <limits.h>

  int maior(int vet[]) //fun��o para achar o maior
  {
      int maior = INT_MIN;
      
      for (int i = 0; i < 10; i++)
    {
      if (vet[i] > maior)
       {
          maior = vet[i];
       }
    }
    return maior;  
  }

int main()
{
    int vet[10],res; //declarando as vari�veis 
    
    for (int i = 0; i < 10; i++)
    {
       scanf("\n%d", &vet[i]);
    }    

    res =  maior(vet);
    
    printf ("O maior elemento �: %d", res);

    return 0;
}
