#include <stdio.h>

int main() {
    
    int nums[5]; //Array dos valores inteiros 
    
    for (int i = 0; i < 5; i++) //Preenchendo o array
    {
        scanf("%d", &nums[i]);
    }
    
    for (int i = 4; i >= 0; i--) //Invertendo o array
    {
        printf("\n%d", nums[i]);
    }
    
    return 0;
}
