#include <stdio.h>

int main(int argc, char **argv)
{
   int tam;

   char string[50];

   tam = strlen(argv[1]);

    printf("O tamanho �: %d",tam);

}

