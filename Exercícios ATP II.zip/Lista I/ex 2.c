#include <stdio.h>


int main()
{
 char array[5];
 
 for (int i = 0; i < 5; i++)
 {
     scanf ("%s", &array[i]);
 }
 for (int i = 0; i < 5; i++)
 {
     printf ("\n%c", array[i]);
 }

 
 

    return 0;
}
