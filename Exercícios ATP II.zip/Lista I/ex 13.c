#include <stdio.h>
#include <stdlib.h>

int main() {
    int numeros[5] = {10, 20, 30, 40, 50}; 
    int *p; // Declara��o do ponteiro

    p = numeros; // Associa o ponteiro ao array

    // Imprime os elementos do array usando o ponteiro
    for (int i = 0; i < 5; i++) {
        printf("Elemento %d: %d\n", i, *p);
        p++;
    }

    return 0;
}
