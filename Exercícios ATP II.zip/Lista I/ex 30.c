/*
  Escreva um programa em C que use um array de ponteiros
  para armazenar 3 strings, ordene as strings em ordem alfab�tica e as imprima.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
   char *mat[3]; //declarando um array de ponteiros de 3 strings
   
   char aux[50]; //vetor auxiliar para receber mat[j]
   
   char aux2[50]; //vetor auxiliar para receber mat[j - 1]
   
   for (int i = 0; i < 3; i++) //alocando mem�ria para as 3 strings
   {
       mat[i] = malloc(51 * sizeof(char));
   }
   
   for (int i = 0; i < 3; i++) 
   {
       scanf("%s", mat[i]);
   }
   
   for(int i = 0; i < 2; i++) //verificando de dois em dois as palavras com o loop
   {
       for(int j = 1; j < 3; j++)
       {
           if(strcmp(mat[j - 1], mat[j]) > 0)
           {
               strcpy(aux, mat[j - 1]);
               strcpy(aux2, mat[j]);
               strcpy(mat[j], aux);
               strcpy(mat[j - 1], aux2);
               
           }
       }
   }

   printf("A sequ�ncia em ordem alfab�tica:\n");
   for (int i = 0; i < 3; i++)
   {
   printf("\n%s",mat[i]);
   }
   
   // Libera��o da mem�ria alocada
    for (int i = 0; i < 3; i++)
    {
        free(mat[i]);
    }
    return 0;
}
