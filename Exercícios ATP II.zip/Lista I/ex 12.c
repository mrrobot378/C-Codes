#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
    srand (time(0));
    
    int array[12],qtd = 0;
    
    for (int i = 0; i < 12; i++)
    {
        array[i] = rand() % 41 - 20;

        if (array[i] < 0)
        {
            qtd = qtd + 1;
        }
    }
    
     printf ("\nQuantidade de negativos: %d", qtd);
     
    return 0;
}
