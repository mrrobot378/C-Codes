#include <stdio.h>
#include <stdlib.h>
/*
  Escreva um programa em C que verifique se todos os ele-
mentos de um array de 5 inteiros s�o positivos.
*/

int main() {
    int array[5], cont = 0; //cont � o contador de positivos
    

    // Preenchendo com 5 elementos o array
    printf("Digite 5 n�meros inteiros:\n");
    for (int i = 0; i < 5; i++) {
        scanf("%d", &array[i]);
    }

    // Verifica��o se os elementos s�o positivos
    for (int i = 0; i < 5; i++) { 
        
        if (array[i] > 0) 
        { 
             cont += 1;
        }
    }

    // Resultado
    if (cont == 5) {
        printf("\nTodos s�o positivos!");
    } else {
        printf("\nN�o s�o todos positivos!");
    }

    return 0;
}
