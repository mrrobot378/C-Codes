 
 /*
 Desenvolva uma fun��o recursiva para encontrar a raiz quadrada de um
 n�mero inteiro utilizando o m�todo de busca bin�ria.
 */
 
 #include <stdio.h>

// Fun��o recursiva para encontrar a raiz quadrada de um n�mero inteiro
int raizQuadradaBinaria(int x, int inicio, int fim) {
    if (inicio > fim) {
        return fim; // Retorna o piso da raiz quadrada
    }

    int meio = (inicio + fim) / 2;
    int quadrado = meio * meio;

    if (quadrado == x) {
        return meio; // Encontrou a raiz quadrada exata
    } else if (quadrado < x) {
        return raizQuadradaBinaria(x, meio + 1, fim); // Busca na metade superior
    } else {
        return raizQuadradaBinaria(x, inicio, meio - 1); // Busca na metade inferior
    }
}

int raizQuadrada(int x) {
    if (x < 2) {
        return x; // Casos base para 0 e 1
    }
    return raizQuadradaBinaria(x, 1, x / 2);
}

int main() {
    int numero = 16;
    printf("A raiz quadrada de %d � %d\n", numero, raizQuadrada(numero));
    return 0;
}

