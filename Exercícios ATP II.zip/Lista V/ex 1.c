/*
  Escreva uma fun��o recursiva para calcular o fatorial de um n�mero.
*/

#include <stdio.h>

// Fun��o recursiva para calcular o fatorial
int fatorial(int n) {
    // Caso base: o fatorial de 0 ou 1 � 1
    if (n == 0 || n == 1) {
        return 1;
    }
    // Caso recursivo: n * fatorial de (n-1)
    else {
        return n * fatorial(n - 1);
    }
}

int main() {
    int numero;
    printf("Digite um n�mero para calcular o fatorial: ");
    scanf("%d", &numero);
    printf("O fatorial de %d �: %d\n", numero, fatorial(numero));
    return 0;
}

