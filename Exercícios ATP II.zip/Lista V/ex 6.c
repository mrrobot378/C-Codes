#include <stdio.h>
#include <locale.h>

/*
 Implemente uma fun��o recursiva para imprimir os elementos de um array
 na ordem inversa.
*/

  #include <stdio.h>

// Fun��o recursiva para imprimir os elementos de um array na ordem inversa
void imprimirReverso(int arr[], int tamanho) {
    if (tamanho == 0) {
        return; // Caso base: se o tamanho for 0, n�o h� mais elementos para imprimir
    }
    printf("%d ", arr[tamanho - 1]); // Imprime o �ltimo elemento do array
    imprimirReverso(arr, tamanho - 1); // Chamada recursiva com tamanho reduzido
}

int main() {
    int array[] = {1, 2, 3, 4, 5};
    int tamanho = sizeof(array) / sizeof(array[0]);

    printf("Array na ordem inversa: ");
    imprimirReverso(array, tamanho);
    printf("\n");

    return 0;
}

