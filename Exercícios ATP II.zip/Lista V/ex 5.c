#include <stdio.h>
#include <locale.h>

// Fun��o recursiva para verificar se um n�mero � primo
int ehPrimo(int n, int divisor) {
    if (n <= 1) {
        return 0; // N�meros menores ou iguais a 1 n�o s�o primos
    }
    if (divisor == 1) {
        return 1; // Se chegamos ao divisor 1, o n�mero � primo
    }
    if (n % divisor == 0) {
        return 0; // Se n � divis�vel por divisor, n�o � primo
    }
    return ehPrimo(n, divisor - 1); // Chamada recursiva
}

int main() {
    setlocale(LC_ALL, "Portuguese");

    int num;
    printf("Digite um n�mero: ");
    scanf("%d", &num);

    if (ehPrimo(num, num - 1)) {
        printf("%d � um n�mero primo!\n", num);
    } else {
        printf("%d n�o � um n�mero primo.\n", num);
    }

    return 0;
}

