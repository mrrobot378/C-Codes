/*
 Desenvolva uma fun��oo recursiva para imprimir todos os n�meros primos
 at� N.
*/

#include <stdio.h>
#include <locale.h>

#include <stdio.h>
#include <locale.h>

int ehPrimo(int n, int divisor) {
    if (n <= 1) {
        return 0; // N�meros menores ou iguais a 1 n�o s�o primos
    }
    if (divisor == 1) {
        return 1; // Se chegamos ao divisor 1, o n�mero � primo
    }
    if (n % divisor == 0) {
        return 0; // Se n � divis�vel por divisor, n�o � primo
    }
    return ehPrimo(n, divisor - 1); // Chamada recursiva
}

void imprimirPrimos(int n) {
    if (n < 2) {
        return; // N�o h� n�meros primos menores que 2
    }
    imprimirPrimos(n - 1); // Chamada recursiva para imprimir n�meros menores
    if (ehPrimo(n, n / 2)) {
        printf("%d ", n); // Imprime o n�mero se for primo
    }
}

int main() {
    setlocale(LC_ALL, "Portuguese");

    int N;
    printf("Digite um n�mero: ");
    scanf("%d", &N);

    printf("N�meros primos at� %d:\n", N);
    imprimirPrimos(N);

    return 0;
}
