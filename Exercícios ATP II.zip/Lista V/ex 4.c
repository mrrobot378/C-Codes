/*
 Desenvolva uma fun��o recursiva para calcular a sequ�ncia de Fibonacci
 at� o en�simo termo.
*/


#include <stdio.h>
#include <locale.h>

// Fun��o recursiva para calcular o en�simo termo da sequ�ncia de Fibonacci
int fibonacci(int n) {
    if (n == 0) {
        return 0;
    } else if (n == 1) {
        return 1;
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}

// Fun��o recursiva para calcular a soma dos termos da sequ�ncia de Fibonacci at� o en�simo termo
int soma_fibonacci(int n) {
    if (n == 0) {
        return 0;
    } else {
        return fibonacci(n) + soma_fibonacci(n - 1);
    }
}

int main() {
	
	setlocale(LC_ALL,"Portuguese");
	
    int n;
    printf("Digite o valor de n: ");
    scanf("%d", &n);
    printf("A soma dos termos da sequ�ncia de Fibonacci at� o %d-�simo termo �: %d\n", n, soma_fibonacci(n));
    return 0;
}

