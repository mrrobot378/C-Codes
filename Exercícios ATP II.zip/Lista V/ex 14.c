/*
 Implemente uma fun��o recursiva para verificar se uma palavra � um
 pal�ndromo.
*/

#include <stdio.h>
#include <string.h>

 int ehPalindromo(char array[], int tam)
 {
 	char aux[50];
 	
 	for (int i = 0; i < tamanho; i++)
 	{
 		aux[i] = array[tam - i];
	 }
 	
 	
 	
 }

int main()
{
  int tamanho;
  char string[50];
  
  printf("Escreva a palavra:\n")
  scanf("%s", string);
  
  tamanho = strlen(string);
  
  ehPalindromo(string, tamanho);
  
  if (ehPalindromo == 0)
  {
  	printf ("Essa palavra � um pal�ndromo!");
  }
  else 
  {
  	("Essa palavra n�o � um pal�ndromo!");
  }

    return 0;
}
