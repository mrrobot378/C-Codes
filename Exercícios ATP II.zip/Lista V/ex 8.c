/*
 Desenvolva uma fun��o recursiva para calcular o MDC (M�ximo Divisor
 Comum) de dois n�meros.
*/

#include <stdio.h>
#include <locale.h>

// Fun��o recursiva para calcular o MDC
int mdc(int a, int b) {
    if (b == 0)
        return a;
    else
        return mdc(b, a % b);
}

int main() {
    int num1, num2;
    setlocale(LC_ALL,"Portuguese");

    // Solicita ao usu�rio para digitar os dois n�meros
    printf("Digite dois n�meros inteiros: ");
    scanf("%d %d", &num1, &num2);

    // Calcula e exibe o MDC
    printf("O MDC de %d e %d �: %d\n", num1, num2, mdc(num1, num2));

    return 0;
}

