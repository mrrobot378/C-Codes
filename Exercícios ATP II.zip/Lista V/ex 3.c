/*
Crie uma fun��o recursiva para encontrar o m�ximo elemento em um array.
*/
#include <stdio.h>

// Fun��o para encontrar o maior entre dois n�meros
int max(int a, int b) {
    return (a > b) ? a : b;
}

// Fun��o recursiva para encontrar o maior elemento em um array
int encontrarMaximo(int array[], int tamanho) {
    // Caso base: se o array tem apenas um elemento, retorne esse elemento
    if (tamanho == 1) {
        return array[0];
    }
    // Caso recursivo: compare o �ltimo elemento com o maior dos elementos anteriores
    return max(array[tamanho - 1], encontrarMaximo(array, tamanho - 1));
}

int main() {
    int array[] = {1, 4, 3, -5, -4, 8, 6};
    int tamanho = 7;
    int maximo = encontrarMaximo(array, tamanho);
    printf("O maior elemento do array �: %d\n", maximo);
    return 0;
}
