#include <stdio.h>
#include <locale.h>

/*
 Crie uma fun��o recursiva para calcular a pot�ncia de um n�mero.
*/

int potencia(int base, int expoente) {
    if (expoente == 0) {
        return 1;  // Caso base
    } else {
        return base * potencia(base, expoente - 1);  // Chamada recursiva
    }
}

int main() {
    setlocale(LC_ALL, "Portuguese");

    int base,expoente;
    printf("Digite a base da pot�ncia:\n");
    scanf("%d", &base);
    printf("Digite o expoente:\n");
    scanf("%d", &expoente);
    int resultado = potencia(base, expoente);

    printf("%d elevado a %d = %d\n", base, expoente, resultado);

    return 0;
}

