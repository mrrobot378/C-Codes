/*
 Implemente uma fun��o recursiva para calcular a soma dos primeiros N
 n�meros naturais.
*/

#include <stdio.h>

 int soma(int n)
 {
    if (n == 1)
    {
        return 1;
    }
    else{
        return n + soma(n - 1);
    }
 }

int main() {
    int numero;
    printf("Digite quais primeiros n�meros naturais quer somar:\n");
    scanf("%d", &numero);
    printf("A soma dos %d primeiros n�meros naturais �: %d\n", numero, soma(numero));
    return 0;
}
