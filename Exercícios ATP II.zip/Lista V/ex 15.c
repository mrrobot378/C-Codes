/*
 Crie uma fun��o recursiva para gerar todos os subconjuntos de um con-
junto dado.
*/

#include <stdio.h>

// Fun��o recursiva para gerar todos os subconjuntos
void gerarSubconjuntos(char *conjunto, char *subconjunto, int i, int j, int n) {
    if (i == n) {
        subconjunto[j] = '\0';
        printf("{ %s }\n", subconjunto);
        return;
    }

    // Inclui o elemento atual no subconjunto
    subconjunto[j] = conjunto[i];
    gerarSubconjuntos(conjunto, subconjunto, i + 1, j + 1, n);

    // Exclui o elemento atual do subconjunto
    gerarSubconjuntos(conjunto, subconjunto, i + 1, j, n);
}

int main() {
    char conjunto[] = {'a', 'b', 'c'};
    int n = 3; // Tamanho do conjunto
    char subconjunto[4] = {0}; // Tamanho do subconjunto + 1 para o caractere nulo

    printf("Os subconjuntos do conjunto {a, b, c} s�o:\n");
    gerarSubconjuntos(conjunto, subconjunto, 0, 0, n);

    return 0;
}

