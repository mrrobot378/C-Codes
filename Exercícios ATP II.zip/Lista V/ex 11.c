/*
  Crie uma fun��o recursiva para encontrar o maior divisor comum de um
  array de n�meros.
*/

#include <stdio.h>
#include <locale.h>

// Fun��o recursiva para calcular o MDC de dois n�meros
int mdc(int a, int b) {
    if (b == 0)
        return a;
        else
        {
        	 return mdc(b, a % b);
		}
   
}

// Fun��o para calcular o MDC de um array de n�meros
int mdc_array(int arr[], int n) {
    int result = arr[0];
    for (int i = 1; i < n; i++) {
        result = mdc(result, arr[i]);
    }
    return result;
}

int main() {
    setlocale(LC_ALL, "Portuguese");
    int arr[10];
    printf("Digite a cole��o de n�meros que queira saber o MDC deles:\n");
    for (int i = 0; i < 10; i++) {
        scanf("%d", &arr[i]);
    }
    int tamanho = 10; // Corrigido para usar o tamanho correto do array
    printf("O MDC dos n�meros �: %d\n", mdc_array(arr, tamanho));
    return 0;
}

