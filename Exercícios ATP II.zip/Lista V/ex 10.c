/*
  Implemente uma fun��o recursiva para calcular a soma dos d�gitos de um
  n�mero inteiro.
*/

#include <stdio.h>
#include <locale.h>


 int soma(int n)
 {
 	if (n == 0)
 	{
 		return 0;
	 }
	 else 
	 {
	 	return (n % 10) + soma(n / 10);
	 }
 }

int main() {
    setlocale(LC_ALL, "Portuguese");
   
   int num;
   
   printf("Digite um n�mero para calcular a soma dos seus d�gitos:");
   scanf("\n%d", &num);
   printf("\nA soma dos d�gitos �: %d",  soma(num));
    return 0;
}


