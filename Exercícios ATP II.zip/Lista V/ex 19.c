/*
 Crie uma fun��o recursiva para calcular o coeficiente binomial C(n, k).
*/

 #include <stdio.h>

// Fun��o recursiva para calcular o coeficiente binomial
int coeficienteBinomial(int n, int k) {
    // Caso base
    if (k == 0 || k == n) {
        return 1;
    }
    // Chamada recursiva
    return coeficienteBinomial(n - 1, k - 1) + coeficienteBinomial(n - 1, k);
}

int main() {
    int n = 5, k = 2;
    printf("C(%d, %d) = %d\n", n, k, coeficienteBinomial(n, k));
    return 0;
}

