/*
 Escreva uma fun��o recursiva para encontrar o n�mero de ocorr�ncias de
 um elemento em um array.
*/

#include <stdio.h>
#include <locale.h>

  int ver(int arry[],int x,int tam)
  {
  	int cont = 0;
  	
  	if(tam == 0)
  	{
  		return 0;
	  }
	  else
	  {
	  	if(arry[tam - 1] == x)
	  	{
	  	return 1 + ver(arry, x, tam - 1);
		  }
		  return ver(arry, x, tam - 1);
	  }
  }

int main()
{
  setlocale(LC_ALL,"Portuguese");

    int array[10],num,tamanho = 10;

    for(int i = 0; i < 10; i++)
    {
    	scanf("%d", &array[i]);
	}
 
   printf("Digite qual elemento quer verificar quantas vezes aparece no array:\n");
   scanf("%d", &num);
    
	int ocorrencias = ver(array,num,tamanho);
	
    printf("A quantidade que %d aparece �: %d\n", num, ocorrencias);
    
    
    return 0;
}
