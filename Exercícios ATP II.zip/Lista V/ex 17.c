#include <stdio.h>

/*
 Escreva uma fun��oo recursiva para calcular o n�mero de caminhos 
 poss�veis em uma grade NxN.
*/

// Fun��o recursiva para calcular o n�mero de caminhos em uma grade NxN
int contarCaminhos(int n, int i, int j) {
    // Se chegamos ao canto inferior direito, h� um caminho
    if (i == n - 1 && j == n - 1) {
        return 1;
    }

    // Se estamos fora dos limites da grade, n�o h� caminho
    if (i >= n || j >= n) {
        return 0;
    }

    // Soma os caminhos movendo para a direita e para baixo
    return contarCaminhos(n, i + 1, j) + contarCaminhos(n, i, j + 1);
}

int main() {
    int n = 3; // Tamanho da grade NxN
    printf("N�mero de caminhos poss�veis em uma grade %dx%d: %d\n", n, n, contarCaminhos(n, 0, 0));
    return 0;
}

