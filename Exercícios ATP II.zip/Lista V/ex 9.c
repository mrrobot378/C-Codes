/*
 Escreva uma fun��o recursiva para inverter uma string.
*/

#include <stdio.h>
#include <locale.h>


// Fun��o recursiva para inverter uma string
void inversor(char array[], int tamanho) {
    if (tamanho == 0) {
        return;
    } else {
        printf("%c", array[tamanho - 1]);
        inversor(array, tamanho - 1);
    }
}

int main() {

    setlocale(LC_ALL,"Portuguese");
    
    char string[100];
    
    printf("Digite a string que ser� invertida:\n");
    scanf("%s", string);

    int tamanho = strlen(string);
    
    printf("String invertida: ");
    inversor(string, tamanho);
    printf("\n");
    
    return 0;
}


