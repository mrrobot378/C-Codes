
/*
Implemente uma fun��o recursiva em C para resolver o problema da Torre de Han�i
*/

 #include <stdio.h>

// Fun��o recursiva para resolver a Torre de Han�i
void torreDeHanoi(int n, char origem, char destino, char auxiliar) {
    if (n == 1) {
        printf("Mover disco 1 de %c para %c\n", origem, destino);
        return;
    }
    torreDeHanoi(n - 1, origem, auxiliar, destino);
    printf("Mover disco %d de %c para %c\n", n, origem, destino);
    torreDeHanoi(n - 1, auxiliar, destino, origem);
}

int main() {
    int n = 3; // N�mero de discos
    torreDeHanoi(n, 'A', 'C', 'B'); // A, B e C s�o os nomes das hastes
    return 0;
}

