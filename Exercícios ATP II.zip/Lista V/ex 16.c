#include <stdio.h>

/*
 Desenvolva uma fun��oo recursiva para calcular a sequ�ncia de Ackermann.
*/

// Fun��o de Ackermann
int ackermann(int m, int n) {
    if (m == 0) {
        return n + 1;
    } else if (m > 0 && n == 0) {
        return ackermann(m - 1, 1);
    } else if (m > 0 && n > 0) {
        return ackermann(m - 1, ackermann(m, n - 1));
    }
    return -1; // Caso nunca alcan�ado, apenas para evitar warnings
}

int main() {
    int m = 3, n = 4;
    printf("Ackermann(%d, %d) = %d\n", m, n, ackermann(m, n));
    return 0;
}

