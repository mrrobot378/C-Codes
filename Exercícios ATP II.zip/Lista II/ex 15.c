#include <stdio.h>

/*
 Escreva um programa em C que inverta a ordem das linhas de
uma matriz 3x3.
*/

int main()
{   
    int mat[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9},
    };
    
    int matp[3][3]; // matp = matriz provis�ria que vai receber a linha em outra ordem

    // Invertendo a ordem das linhas
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            matp[i][j] = mat[2 - i][j];
        }
    }
    
    printf("A matriz com linhas invertidas:\n");

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            printf("%d ", matp[i][j]);
        }
        printf("\n");
    }    
    return 0;
}

