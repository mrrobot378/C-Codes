/*
 Escreva um programa em C que preencha uma matrjz 3x3 com
 n�meros primos e depois calcule o produto dos elementos da diagonal secund�ria.
*/

#include <stdio.h>

// Fun��o para verificar se um n�mero � primo
int ehPrimo(int num) {
    if (num <= 1) return 0;
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) return 0;
    }
    return 1;
}

int main() {
    int matriz[3][3];
    int primos[9];
    int count = 0;
    int num = 2;

    // Preencher o array de n�meros primos
    while (count < 9) {
        if (ehPrimo(num)) {
            primos[count] = num;
            count++;
        }
        num++;
    }

    // Preencher a matriz 3x3 com os n�meros primos
    count = 0;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            matriz[i][j] = primos[count];
            count++;
        }
    }

    // Calcular o produto dos elementos da diagonal secund�ria
    int produto = 1;
    for (int i = 0; i < 3; i++) {
        produto *= matriz[i][2 - i];
    }

    // Exibir a matriz e o produto da diagonal secund�ria
    printf("Matriz 3x3 com n�meros primos:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }
    printf("Produto dos elementos da diagonal secund�ria: %d\n", produto);

    return 0;
}

