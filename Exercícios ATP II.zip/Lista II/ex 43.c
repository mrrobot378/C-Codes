/*
 Escreva um programa em C que calcule a soma dos elementos
 abaixo da diagonal principal de uma matriz 4x4.
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{   
    int soma = 0;
    
    int mat[4][4] = {
      {1,2,3,4},
      {5,6,7,8},
      {9,10,11,12},
      {13,14,15,16},
    };

       for (int j = 0; j < 3; j++)
       {
           soma += mat[3][2 - j];
       }
   

       for (int j = 0; j < 2; j++)
       {
           soma += mat[2][1 - j];
       }

   
   soma += mat[1][0];
   
   printf("A soma dos elementos �: %d", soma);

    return 0;
}
