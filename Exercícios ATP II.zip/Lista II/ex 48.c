/*
 Escreva um programa em C que preencha uma matriz 4x4 com
 n�umeros aleat�orios e depois calcule a m�dia dos elementos acima da diagonal
 principal.
 
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <limits.h>

int main()
{   
    srand(time(NULL));
    
    float soma = 0;
    
    float media;
    
    int mat[4][4];
    
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            mat[i][j] = rand () %100;
        }
    }
    
    for (int i = 0; i < 1; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            soma += mat[i][3 - j];
        }
    }
    
        for (int j = 0; j < 2; j++)
        {
            soma += mat[1][3 - j];
        }

    soma += mat[2][3];
 
    media = soma/16;
    
    printf("A m�dia �: %.2f", media);

    return 0;
}
