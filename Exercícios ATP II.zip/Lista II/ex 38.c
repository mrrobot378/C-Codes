/*
 Escreva um programa em C que verifique se uma matriz 3x3 �
uma matriz de Hankel.
*/

#include <stdio.h>

int main()
{   
    int ehHankel = 0;
    
    int mat[3][3] = {
    {1,2,3},
    {2,3,1},
    {3,1,2},
    };

    for(int j = 0; j < 3; j++) //loop para verificar se o segundo elemento da primeira coluna
    //� igual ao primeiro elemento da segunda coluna e ir iterando
    //coloquei o && para comparar se mat[0][0] == mat[2][1] e mat[0][1] == mat[2][2] tamb�m.
    {
        for(int i = 0; i < 2; i++)
        {
            if (mat[i + 1][j] == mat[i][1 + i] && mat[0][0] == mat[2][1] && mat[0][1] == mat[2][2])
            {
                ehHankel = 1;
            }
        }
    }

    if (ehHankel == 1)
    {
        printf("� uma matriz de Hankel!");
    }else if (ehHankel == 0)
    {
        printf("N�o � uma matriz de Hankel!");
    }

    return 0;
}
