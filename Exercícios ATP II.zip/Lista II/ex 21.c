#include <stdio.h>

/*
 Escreva um programa em C que verifique se uma matriz 3x3 �
 uma matriz de permuta��o.
*/

// Fun��o para verificar se a matriz � de permuta��o
int ehMatrizPermutacao(int matriz[3][3]) {
    for (int i = 0; i < 3; i++) {
        int somaLinha = 0;
        int somaColuna = 0;
        for (int j = 0; j < 3; j++) {
            somaLinha += matriz[i][j];
            somaColuna += matriz[j][i];
        }
        if (somaLinha != 1 || somaColuna != 1) {
            return 0; // N�o � matriz de permuta��o
        }
    }
    return 1; // � matriz de permuta��o
}

int main() {
    int matriz[3][3];

    // Leitura dos elementos da matriz
    printf("Digite os elementos da matriz 3x3:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            scanf("%d", &matriz[i][j]);
        }
    }

    // Verifica��o e resultado
    if (ehMatrizPermutacao(matriz)) {
        printf("A matriz � uma matriz de permuta��o.\n");
    } else {
        printf("A matriz n�o � uma matriz de permuta��o.\n");
    }

    return 0;
}

