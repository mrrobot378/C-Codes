/*
Escreva um programa em C que encontre o maior elemento em
uma matriz 3x3.
*/

#include <stdio.h>
#include <limits.h>

int main()
{
    int maior = INT_MIN;
    
    int mat[3][3] = {
    {1,2,3},
    {4,5,6},
    {7,8,9},
};
  
  for (int i = 0; i < 3; i++)
  {  
    for (int j = 0; j < 3; j++)
    {
         if (mat[j][i] > maior)
         {
             maior = mat[j][i];
         }
    }
  }
  
  printf ("O maior elemento �: %d", maior);


    return 0;
}
