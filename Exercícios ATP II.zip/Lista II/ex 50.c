/*
 Escreva um programa em C que verifique se uma matriz 4x4  �e
 uma matriz de Drazin.
*/

#include <stdio.h>

#define N 4

// Fun��o para multiplicar duas matrizes
void multiplicarMatrizes(int primeiraMatriz[N][N], int segundaMatriz[N][N], int resultado[N][N]) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            resultado[i][j] = 0;
            for (int k = 0; k < N; ++k) {
                resultado[i][j] += primeiraMatriz[i][k] * segundaMatriz[k][j];
            }
        }
    }
}

// Fun��o para verificar se duas matrizes s�o iguais
int matrizesSaoIguais(int matriz1[N][N], int matriz2[N][N]) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            if (matriz1[i][j] != matriz2[i][j]) {
                return 0; // falso
            }
        }
    }
    return 1; // verdadeiro
}

// Fun��o principal para verificar se uma matriz � uma matriz de Drazin
int eMatrizDrazin(int A[N][N], int X[N][N]) {
    int AX[N][N], XA[N][N], XAX[N][N], Ak[N][N], Ak1[N][N];

    // Calcula AX e XA
    multiplicarMatrizes(A, X, AX);
    multiplicarMatrizes(X, A, XA);

    // Verifica se AX == XA
    if (!matrizesSaoIguais(AX, XA)) {
        return 0; // falso
    }

    // Calcula XAX
    multiplicarMatrizes(X, AX, XAX);

    // Verifica se XAX == X
    if (!matrizesSaoIguais(XAX, X)) {
        return 0; // falso
    }

    // Inicializa Ak e Ak1
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            Ak[i][j] = (i == j) ? 1 : 0; // Ak = I (matriz identidade)
            Ak1[i][j] = A[i][j];
        }
    }

    // Verifica se Ak1 * X == Ak
    for (int k = 0; k < N; ++k) {
        multiplicarMatrizes(Ak1, A, Ak1); // Ak1 = A^(k+1)
        multiplicarMatrizes(Ak1, X, Ak1); // Ak1 = A^(k+1) * X
        if (matrizesSaoIguais(Ak1, Ak)) {
            return 1; // verdadeiro
        }
        // Atualiza Ak = A^k
        multiplicarMatrizes(Ak, A, Ak);
    }

    return 0; // falso
}

int main() {
    int A[N][N] = {
        {1, 2, 3, 4},
        {5, 6, 7, 8},
        {9, 10, 11, 12},
        {13, 14, 15, 16}
    };

    int X[N][N] = {
        {1, 0, 0, 0},
        {0, 1, 0, 0},
        {0, 0, 1, 0},
        {0, 0, 0, 1}
    };

    if (eMatrizDrazin(A, X)) {
        printf("A matriz � uma matriz de Drazin.\n");
    } else {
        printf("A matriz n�o � uma matriz de Drazin.\n");
    }

    return 0;
}

