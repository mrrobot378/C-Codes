/*
Escreva um programa em C que encontre o menor elemento em
uma matriz 4x4.
*/

#include <stdio.h>
#include <limits.h>

int main()
{
    int menor = INT_MAX;
    
    int mat[4][4] = {
    {1,2,3,11},
    {4,5,6,23},
    {7,8,9,45},
    {60,22,34,55},
    
};
  
  for (int i = 0; i < 4; i++)
  {  
    for (int j = 0; j < 4; j++)
    {
         if (mat[j][i] < menor)
         {
             menor = mat[j][i];
         }
    }
  }
  
  printf ("O menor elemento �: %d", menor);


    return 0;
}
