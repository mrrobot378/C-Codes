/*
 /*
 Escreva um programa em C que preencha uma matriz 5x5 com
 n�meros aleat�rios e depois encontre o segundo menor elemento.
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <limits.h>

int main()
{   srand(time(NULL));
   
    int menor = RAND_MAX; //criando uma vari�vel base para come�ar com o menor
    
    int menor2 = RAND_MAX; //outra vari�vel para conseguirmos ter o segundo menor
    
    int mat[5][5];
    
    for (int i = 0; i < 5; i++) //loop preenchendo o vetor com n�meros aleat�rios
    {
        for (int j = 0; j < 5; j++)
        {
            mat[i][j] = rand () %100;
        }
    }

    printf("Matriz:\n"); //exibindo a matriz para ter certeza que � o segundo menor
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            printf("%d\t",mat[i][j]);
        }
    printf("\n");    
    }
    
    for (int i = 0; i < 5; i++) //compara��o para termos o menor n�mero
    {
        for (int j = 0; j < 5; j++)
        {
            if (mat[i][j] < menor)
            {
                menor = mat[i][j];
            }
        }
    }
    
    for (int i = 0; i < 5; i++) //compara��o para termos o segundo menor n�mero
    {
        for (int j = 0; j < 5; j++)
        {
            if (mat[i][j] < menor2 && mat[i][j] > menor)
            {
                menor2 = mat[i][j];
            }
        }
    }

    printf("\nO segundo menor elemento �: %d", menor2);

    return 0;
}
