/*
 Escreva um programa em C que calcule a soma das colunas de
uma matriz 4x3.
*/

#include <stdio.h>

int main()
{
    int soma = 0;
    
    int mat[4][3] = {
        {1,2,3},
        {4,5,6},
        {7,8,9},
        {10,11,12},
    };

    for (int j = 0; j < 3; j++)
    {
        for (int i = 0; i < 4; i++)
        {
            soma += mat[i][j];
        }
    }

   printf ("A soma das colunas �: %d", soma);

    return 0;
}
