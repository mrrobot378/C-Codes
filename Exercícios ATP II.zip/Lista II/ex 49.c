/*
 Escreva um programa em C que calcule a transposta de uma
 matriz 3x4.
*/

#include <stdio.h> //n�o entendi claramente os sentido vago de "calcular" do exerc�cio

int main()
{
    int mat[3][4] = { //declarando a matriz original
      {1,2,3,4},
      {5,6,7,8},
      {9,10,11,12},
    };

    int matT[4][3]; //declarando a transposta
    
    for (int i = 0; i < 3; i++) //loop para fazer a transposta
    {
        for(int j = 0; j < 4; j++)
        {
            matT[j][i] = mat[i][j];
        }
    }

    printf("Matriz transposta:\n");
    for (int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 3; j++)
        {
        printf ("%d\t",matT[i][j]);
        }
    printf ("\n");    
    }

    return 0;
}
