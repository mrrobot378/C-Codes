#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define TAMANHO 5

void imprimirGrade(int grade[TAMANHO][TAMANHO]) {
    for (int i = 0; i < TAMANHO; i++) {
        for (int j = 0; j < TAMANHO; j++) {
            printf("%c ", grade[i][j] ? 'O' : '.');
        }
        printf("\n");
    }
}

void copiarGrade(int origem[TAMANHO][TAMANHO], int destino[TAMANHO][TAMANHO]) {
    for (int i = 0; i < TAMANHO; i++) {
        for (int j = 0; j < TAMANHO; j++) {
            destino[i][j] = origem[i][j];
        }
    }
}

int contarVizinhos(int grade[TAMANHO][TAMANHO], int x, int y) {
    int contagem = 0;
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) continue;
            int nx = x + i;
            int ny = y + j;
            if (nx >= 0 && nx < TAMANHO && ny >= 0 && ny < TAMANHO) {
                contagem += grade[nx][ny];
            }
        }
    }
    return contagem;
}

void atualizarGrade(int grade[TAMANHO][TAMANHO]) {
    int novaGrade[TAMANHO][TAMANHO] = {0};
    for (int i = 0; i < TAMANHO; i++) {
        for (int j = 0; j < TAMANHO; j++) {
            int vizinhos = contarVizinhos(grade, i, j);
            if (grade[i][j] && (vizinhos == 2 || vizinhos == 3)) {
                novaGrade[i][j] = 1;
            } else if (!grade[i][j] && vizinhos == 3) {
                novaGrade[i][j] = 1;
            } else {
                novaGrade[i][j] = 0;
            }
        }
    }
    copiarGrade(novaGrade, grade);
}

int main() {
    int grade[TAMANHO][TAMANHO] = {
        {0, 1, 0, 0, 0},
        {0, 0, 1, 0, 0},
        {1, 1, 1, 0, 0},
        {0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0}
    };

    while (1) {
        imprimirGrade(grade);
        atualizarGrade(grade);
        usleep(200000); // Atraso de 200ms
        system("cls"); // Limpa a tela no Windows
    }

    return 0;
}

