#include <stdio.h>

#define TAMANHO 3

// Fun��o para multiplicar duas matrizes
void multiplicar(int matriz1[TAMANHO][TAMANHO], int matriz2[TAMANHO][TAMANHO], int resultado[TAMANHO][TAMANHO]) {
    for (int i = 0; i < TAMANHO; i++) {
        for (int j = 0; j < TAMANHO; j++) {
            resultado[i][j] = 0;
            for (int k = 0; k < TAMANHO; k++) {
                resultado[i][j] += matriz1[i][k] * matriz2[k][j];
            }
        }
    }
}

// Fun��o para verificar se uma matriz � a matriz identidade
int ehIdentidade(int matriz[TAMANHO][TAMANHO]) {
    for (int i = 0; i < TAMANHO; i++) {
        for (int j = 0; j < TAMANHO; j++) {
            if ((i == j && matriz[i][j] != 1) || (i != j && matriz[i][j] != 0)) {
                return 0;
            }
        }
    }
    return 1;
}

int main() {
    int matriz1[TAMANHO][TAMANHO], matriz2[TAMANHO][TAMANHO], resultado[TAMANHO][TAMANHO];

    // Leitura das matrizes
    printf("Digite os elementos da primeira matriz 3x3:\n");
    for (int i = 0; i < TAMANHO; i++) {
        for (int j = 0; j < TAMANHO; j++) {
            scanf("%d", &matriz1[i][j]);
        }
    }

    printf("Digite os elementos da segunda matriz 3x3:\n");
    for (int i = 0; i < TAMANHO; i++) {
        for (int j = 0; j < TAMANHO; j++) {
            scanf("%d", &matriz2[i][j]);
        }
    }

    // Multiplica a primeira matriz pela segunda
    multiplicar(matriz1, matriz2, resultado);

    // Verifica se o resultado � a matriz identidade
    if (ehIdentidade(resultado)) {
        printf("As matrizes s�o ortogonais.\n");
    } else {
        printf("As matrizes n�o s�o ortogonais.\n");
    }

    return 0;
}
s
