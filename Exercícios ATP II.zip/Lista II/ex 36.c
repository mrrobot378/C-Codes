#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*
Escreva um programa em C que preencha uma matriz 5x5 com
n�meros aleat�rios e depois ordene os elementos de cada coluna.
*/

int main() {
    int matriz[5][5];
    srand(time(NULL)); // Define a semente para n�meros aleat�rios

    // Preenche a matriz com n�meros aleat�rios
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            matriz[i][j] = rand() % 100; // Gera n�meros aleat�rios entre 0 e 99
        }
    }

    // Ordena os elementos de cada coluna
    for (int j = 0; j < 5; j++) {
        for (int i = 0; i < 4; i++) {
            for (int k = i + 1; k < 5; k++) {
                if (matriz[i][j] > matriz[k][j]) {
                    int temp = matriz[i][j];
                    matriz[i][j] = matriz[k][j];
                    matriz[k][j] = temp;
                }
            }
        }
    }

    // Imprime a matriz
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            printf("%d\t", matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}

