/*
 Escreva um programa em C que verifique se uma matriz 2x2  �e
uma matriz de Sylvester.
*/

#include <stdio.h>

// Fun��o para verificar se uma matriz 2x2 � uma matriz de Sylvester
int ehMatrizDeSylvester(int matriz[2][2]) {
    // Verificar se a matriz � sim�trica
    if (matriz[0][1] != matriz[1][0]) {
        return 0;
    }

    // Verificar se os determinantes dos menores principais s�o positivos
    int det1 = matriz[0][0];
    int det2 = matriz[0][0] * matriz[1][1] - matriz[0][1] * matriz[1][0];

    if (det1 > 0 && det2 > 0) {
        return 1;
    }

    return 0;
}

int main() {
    int matriz[2][2] = {{1, 2}, {2, 3}};

    if (ehMatrizDeSylvester(matriz)) {
        printf("A matriz � uma matriz de Sylvester.\n");
    } else {
        printf("A matriz n�o � uma matriz de Sylvester.\n");
    }

    return 0;
}


    return 0;
}

