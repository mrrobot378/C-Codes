#include <stdio.h>

/*
 Escreva um programa em C que verifique se uma matriz 3x3  �e
 uma matriz identidade.
*/

int main() {
    int ehIdentidade = 1; // Inicialmente assumimos que � uma matriz identidade
    
    int mat[3][3] = {
        {1, 0, 0},
        {0, 1, 2},
        {0, 0, 1},
    };

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (i == j && mat[i][j] != 1) {
                ehIdentidade = 0; // Elemento da diagonal principal n�o � 1
            } else if (i != j && mat[i][j] != 0) {
                ehIdentidade = 0; // Elemento fora da diagonal principal n�o � 0
            }
        }
    }

    if (ehIdentidade) {
        printf("� uma matriz identidade!\n");
    } else {
        printf("N�o � uma matriz identidade!\n");
    }

    return 0;
}

