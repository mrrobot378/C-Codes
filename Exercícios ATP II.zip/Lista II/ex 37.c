#include <stdio.h>
#include <stdlib.h>

/*
Escreva um programa em C que multiplique uma matriz 2x3 por
uma matriz 3x4 e armazene o resultado em uma matriz 2x4.
*/

int main (){
 int matriz[2][3] = {
        {1,2,3},
        {4,5,6},
    };
    
 int matriz_2[3][4]= {
        {1,2,3,4},
        {3,4,6,7},
        {5,6,7,8},
    };
    
 int matriz_3[2][4];


    for(int i = 0; i < 2; i++){ // multiplica��o das matrizes.
        for(int j = 0; j < 4; j++){
            matriz_3[i][j] = 0; // at� esse for � usado pra zerar a matriz c
        }
    }

    for(int i = 0; i < 2; i++){ // multiplicando as matrizes.
        for(int j = 0; j < 4; j++){
            for(int d = 0; d < 3; d++){
                matriz_3[i][j] = matriz_3[i][j] + matriz[i][d] * matriz_2[d][j];
            }
        }
    }

    printf("\n");
    printf("\n");
    printf("\n");
    printf("Matriz Multiplicada: \n");
    for (int i = 0; i < 2; i++){ //exibindo a matriz_c.
        if (i != 0){
            printf("\n");
        }
        for(int j = 0; j < 4; j++){
            printf(" %d ", matriz_3[i][j]);
        }
    }
    printf("\n");
    printf("\n");
    printf("\n");


return 0;
}
