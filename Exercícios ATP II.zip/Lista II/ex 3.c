/*
 Escreva um programa em C que verifique se duas matrizes 2x2
s�o iguais.
*/

#include <stdio.h>

int main()
{   
    int ehIgual = 1;
    
    int matriz1[2][2] = {
        {1,2},
        {4,5}
    };
    
    int matriz2[2][2] = {
        {1,2},
        {4,5}
    };
    
    for (int i = 0; i < 2; i++)
    {
        for(int j = 0; j < 2; j++)
        {
            if (matriz1[i][j] != matriz2[i][j])
            {
                ehIgual = 0;
                break;
            }
        }
    }    
        
    
    if (ehIgual == 1)
    {
        printf ("S�o matrizes iguais!");
    }else if (ehIgual == 0){
        printf ("N�o s�o matrizes iguais!");
    }
            
    
    return 0;
}
