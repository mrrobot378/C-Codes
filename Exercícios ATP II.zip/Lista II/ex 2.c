/*
Escreva um programa em C que calcule a soma dos elementos de
uma matriz 4x4.
*/

#include <stdio.h>

int main()
{
    int soma = 0;
    int matriz[4][4] = {
        {1,2,3},
        {4,5,6},
        {7,8,9},
        {10,11,12},
    };
    
    for (int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            soma += matriz[i][j];        
        }
    }
    
    printf ("Resultado da soma dos elementos da matriz: %d", soma);
    
    return 0;
}

