#include <stdio.h>

/*
 Escreva um programa em C que calcule o determinante de uma
matriz quadrada 3x3.
*/

int main() {
    int matriz[3][3];
    int i, j;
    int determinante;

    // Leitura dos elementos da matriz
    printf("Digite os elementos da matriz 3x3:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            printf("Elemento [%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

    // C�lculo do determinante
    determinante = matriz[0][0] * (matriz[1][1] * matriz[2][2] - matriz[1][2] * matriz[2][1]) -
                   matriz[0][1] * (matriz[1][0] * matriz[2][2] - matriz[1][2] * matriz[2][0]) +
                   matriz[0][2] * (matriz[1][0] * matriz[2][1] - matriz[1][1] * matriz[2][0]);

    // Exibi��o do resultado
    printf("O determinante da matriz �: %d\n", determinante);

    return 0;
}

