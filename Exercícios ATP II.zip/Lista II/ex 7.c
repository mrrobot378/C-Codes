/*
Escreva um programa em C que verifique se uma matriz 3x3  �e
sim�trica.
*/

#include <stdio.h>

int main()
{
    int ehSimetrica = 1; //vari�vel para verificar com if e printar 
    //se � sim�trica ou n�o (assumimos inicialmente como verdade)
    
   int mat[3][3] = {
     {1,2,3}, 
     {4,5,6}, 
     {7,8,9}, 
   };
   
   int matrizt[3][3]; //matrizt = matriz transposta

   for (int i = 0; i < 3; i++)
   {
       for (int j = 0; j < 3; j++)
       {
           matrizt[j][i] = mat[i][j];
       }
   }
 
   for (int i = 0; i < 3; i++)
   {
      for (int j = 0; j < 3; j++){
           if (matrizt[j][i] != mat[j][i])
       {
           ehSimetrica = 0;
           break;
       }
       }
       
   }

   if (ehSimetrica == 0){
     printf ("A matriz n�o � sim�trica!");    
   }else {
       printf ("A matriz � sim�trica!");
   }
   
 
    return 0;
}
