/*
Escreva um programa em C que encontre a posi��o (linha e coluna)
de um elemento espec�fico em uma matriz 3x3.
*/

#include <stdio.h>

int main()
{
    int linha;
    
    int coluna;
    
    int mat[3][3] = {
      {1,2,3},
      {4,5,6},
      {7,8,9},
    };

   printf ("Qual elemento voc� quer acessar da matriz?(Digite a linha e depois a coluna):\n");
   scanf ("%d", &linha);
   scanf ("\n%d", &coluna);
   
   printf ("O elemento nessa posi��o �: %d", mat[linha][coluna]);

    return 0;
}
