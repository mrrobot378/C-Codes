/*
 Escreva um programa em C que multiplique uma matriz 2x3 por
 uma matriz 3x2 e armazene o resultado em uma matriz 2x2.
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int mat[2][3] = {
      {1,2,3},
      {4,5,6},
    };
    
    int mat2[3][2] = {
      {7,8},
      {9,10},
      {11,12},
    };
    
    int matR[2][2] = {0};
    
    
    
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            for (int d = 0; d < 2; d++)
            {
                matR[i][d] += mat[i][j] * mat2[j][d]; 
            }
        }
    }

    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            printf("%d\t", matR[i][j]);
        }
    printf("\n");    
    }
    
    return 0;
}
