/*
 Escreva um programa em C que verifique se uma matriz 3x3  �
 uma matriz de Hankel circular.
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{   
    int cont = 1;
    
    int mat[3][3] = {
      {1,2,5},
      {5,1,2},
      {2,5,1},
    };

    if (mat[0][0] != mat[1][1] || mat[0][0] != mat[2][2] ||
        mat[0][1] != mat[1][2] || mat[0][1] != mat[2][0] ||
        mat[0][2] != mat[1][0] || mat[0][2] != mat[2][1]) {
        cont = 0;
    }

   if (cont == 0)
   {
       printf("N�o � uma matriz de Hankel circular!");
   }else if (cont == 1)
   {
       printf("� uma matriz de Hankel circular!");
   }

    return 0;
}
