/*
 Escreva um programa em C que multiplique uma matriz 3x3 por
 sua transposta.
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{   
    int matR[3][3] = {0}; // Inicializa a matriz de resultados com zeros
    
    int matT[3][3];
    
    int mat[3][3] = {
      {1, 2, 5},
      {5, 1, 2},
      {2, 5, 1},
    };

    // Calcula a transposta da matriz
    for (int j = 0; j < 3; j++)
    {
        for(int i = 0; i < 3; i++)
        {
            matT[i][j] = mat[j][i];
        }
    }

    // Multiplica a matriz original pela sua transposta
    for (int i = 0; i < 3; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            matR[i][j] = 0; // Inicializa o elemento da matriz de resultados
            for(int k = 0; k < 3; k++)
            {
                matR[i][j] += mat[i][k] * matT[k][j];
            }
        }
    }

    // Imprime a matriz resultante
    for (int i = 0; i < 3; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            printf("%d\t", matR[i][j]);
        }
        printf("\n");  
    }

    return 0;
}

