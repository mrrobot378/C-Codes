/*
 Escreva um programa em C que implemente a busca bin�ria em
 uma matriz ordenada 4x4.
*/

#include <stdio.h>

int main()
{   
    int num, existe = 0;
    
    int mat[3][3] =
    {
        {1,2,3},
        {4,5,6},
        {7,8,9},
    };
    
    printf("Insira o valor que deseja saber se est� na matriz:\n");
    scanf("%d", &num);
    

    for (int i = 0; i < 3; i++)  //loop para verificar se existe o elemento 
    {
        for (int j = 0; j < 3; j++)
        {
            if (mat[i][j] == num)
            {
                existe = 1;
            }
        }
    }

    if (existe == 1) //verifica��o se o elemento existe
    {
        printf("O elemento est� na matriz!");
    }else if (existe == 0)
    {
        printf("O elemento n�o est� na matriz!");
    }
    
    return 0;
}
