/*
 Escreva um programa em C que multiplique uma matriz 3x3 por
 um escalar.
*/

#include <stdio.h>

int main()
{
    int es = 2; //escalar que ir� multiplicar a mat (matriz)
    
    int mat[3][3] =
    {
        {1,2,3},
        {4,5,6},
        {7,8,9},
    };
    
    int matE[3][3]; //matE = matriz do produto do escalar 

    for (int i = 0; i < 3; i++) 
    {
        for (int j = 0; j < 3; j++)
        {
            matE[i][j] = mat[i][j] * 2;
        }
    }

    for (int i = 0; i < 3; i++) //loop para mostrar a matE
    {
        for (int j = 0; j < 3; j++)
        {
            printf ("%d\t", matE[i][j]);
        }
    printf ("\n");
    }


    return 0;
}
