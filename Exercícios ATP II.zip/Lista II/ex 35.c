#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

/*
 Escreva um programa em C que verifique se uma matriz 4x4 �
 uma matriz de Cauchy.
*/

int main()
{  
    int cont = 0; //contador para ver se todos os 16 elementos s�o represent�veis por fra��o
    
    int v[16] = {2,3,7,8,11,13,17,9,19,23,5,10,15,26,21,51};
    
    int v2[16] = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
    
    int mat[4][4] = {
        {2, 3, 7, 8},
        {11, 13, 17, 9},
        {19, 23, 5, 10},
        {15, 26, 21, 51},
    };
    
    for (int i = 0; i < 16; i++) 
    {
        for (int j = 0; j < 16; j++)
        {
           if (mat[i][j] == v[j]/v2[j])
           cont += 1;
        }
    }

    if (cont == 16)
    {
        printf("� uma matriz de Cauchy!");
    }else if (cont != 16)
    {
        printf("N�o � uma matriz de Cauchy!");
    }

    return 0;
}

