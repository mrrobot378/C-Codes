/*
Escreva um programa em C que calcule a m �edia dos elementos de
uma matriz 2x4.
*/

#include <stdio.h>

int main()
{
    float soma = 0; //para realizar a soma 
    float media;
   
    int mat[2][4] = {
    {1,2,3,4},
    {5,6,7,8},
};
  
  for (int i = 0; i < 2; i++)
  {  
    for (int j = 0; j < 4; j++)
    {
        soma += mat[i][j]; 
    }
  }
  
  media = soma/8;
  
  printf ("A m�dia �: %.2f", media);


    return 0;
}
