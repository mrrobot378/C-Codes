/*
  Escreva um programa em C que verifique se uma matriz 3x3 �
  uma matriz de Toeplitz. 
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ehToep = 0;
    
     int mat[3][3]=
     {
         {1,2,3},
         {4,1,6},
         {7,8,1},
     };
     
        if (mat[0][0] == mat[1][1] == mat[2][2])
        {
            ehToep = 1;
        }
    
    if (ehToep == 1)
    {
    printf("� uma matriz Toeplitz!");
    }else if (ehToep == 0)
    {
    printf("N�o � uma matriz Toeplitz!");   
    }
    
    return 0;
}
