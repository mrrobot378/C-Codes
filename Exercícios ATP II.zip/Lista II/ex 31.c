/*
 Escreva um programa em C que verifique se uma matriz 3x3  �e
 uma matriz de Vandermonde. (1,x,x^2)
*/

#include <stdio.h>

int main()
{   
    int cont = 0; //cont = contador de linha "corretas"
    
    int mat[3][3] = {
        {1,2,4},
        {1,5,25},
        {1,8,64},
    };

    for (int i = 0; i < 3; i++) //loop verificando se cada linha corresponde ao padr�o
    {
            if (mat[i][0] == 1 && mat[i][1] && mat[i][2] == mat[i][1] * mat[i][1])
            {
                cont += 1;
            }
    }

    if (cont == 3)
    {
        printf("� uma matriz Vandermond!");
    }else if (cont != 3)
    {
        printf("N�o � uma matriz Vandermond!");
    }

    return 0;
}
