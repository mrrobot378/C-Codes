#include <stdio.h>

void multiplicaMatrizes(int A[3][3], int B[3][3], int C[3][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            C[i][j] = 0;
            for (int k = 0; k < 3; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

void inverteMatriz(int A[3][3], int inv[3][3]) {

}

int main() {
    int A[3][3], B[3][3], P[3][3], P_inv[3][3], temp[3][3];
    int i, j;

    // Leitura das matrizes A, B e P
    printf("Digite os elementos da matriz A 3x3:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &A[i][j]);
        }
    }

    printf("Digite os elementos da matriz B 3x3:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &B[i][j]);
        }
    }

    printf("Digite os elementos da matriz P 3x3:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &P[i][j]);
        }
    }

    // Invers�o da matriz P
    inverteMatriz(P, P_inv);

    // C�lculo de P_inv * A * P
    multiplicaMatrizes(P_inv, A, temp);
    multiplicaMatrizes(temp, P, temp);

    // Verifica��o se P_inv * A * P � igual a B
    int semelhantes = 1;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            if (temp[i][j] != B[i][j]) {
                semelhantes = 0;
                break;
            }
        }
        if (!semelhantes) break;
    }

    if (semelhantes) {
        printf("As matrizes s�o semelhantes.\n");
    } else {
        printf("As matrizes n�o s�o semelhantes.\n");
    }

    return 0;
}

