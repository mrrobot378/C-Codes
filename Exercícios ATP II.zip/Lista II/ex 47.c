/*
 Escreva um programa em C que verifique se uma matriz 3x3 �e
 uma matriz de circulante.
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <limits.h>

int main()
{   
    int ehC = 1;
    
    int mat[3][3]= {
        {1,2,3},
        {3,1,2},
        {2,3,1},
    };
    
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            if(mat[i][1 - j] != mat[1 + i][2 - j] && mat[0][2] != mat[1][0])
            {
              ehC = 0;    
            }
        }
    }

    if(ehC == 0)
    {
        printf("N�o � uma matriz circulante!");
    }
    else if (ehC == 1)
    {
        printf("� uma matriz circulante!");
    }
    
    

    return 0;
}
