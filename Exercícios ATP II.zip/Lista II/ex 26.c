/*
 Escreva um programa em C que verifique se uma matriz 3x3  �e
 uma matriz esparsa (maioria dos elementos s�o zeros).
*/

#include <stdio.h>

int main()
{
    int cont; //contador dos zeros
    
    int cont1; //contador de n�meros diferentes de zero
    
    int mat[3][3] = //uma matriz esparsa (mas poderia n�o ser uma)
    {
        {1,0,0},
        {0,5,0},
        {7,0,0},
    };

    for (int i = 0; i < 3; i++) //loop para contar os zeros
    {
        for (int j = 0; j < 3; j++)
        {
            if (mat[i][j] == 0)
            {
                cont += 1;
            }
        }
    }

    for (int i = 0; i < 3; i++) //loop para contar os num�ros diferentes de zero
    {
        for (int j = 0; j < 3; j++)
        {
            if (mat[i][j] != 0)
            {
                cont1 += 1;
            }
        }
    }

    if (cont > cont1) //compara��o para ver se tem mais zeros que num�ros diferentes de zero
    {
        printf("� uma matriz esparsa!");
    }else if (cont < cont1)
    {
        printf ("N�o � uma matriz esparsa!"); 
    }

    return 0;
}
