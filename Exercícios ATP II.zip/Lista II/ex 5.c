#include <stdio.h>

/*
 Escreva um programa em C que multiplique duas matrizes 3x3.
*/

int main() {
    int matr[3][3]; // matriz resultante da multiplica��o de matrizes
    
    int mat1[3][3] = {
        {1, 3, 4},
        {4, 9, 6},
        {7, 8, 2}
    };
    
    int mat2[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };

    // Multiplica��o de matrizes
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            for (int k = 0; k < 3; k++) {
                matr[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }

    // Impress�o da matriz resultante
    printf("Matriz resultante:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%d ", matr[i][j]);
        }
        printf("\n");
    }
    
    return 0;
}

