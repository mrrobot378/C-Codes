/*
Escreva um programa em C que conte quantos elementos pares
existem em uma matriz 3x3.
*/

#include <stdio.h>

int main()
{
    int cont = 0; //para realizar a contagem de pares
   
    int mat[3][3] = {
    {1,2,3},
    {4,5,6},
    {7,8,9},
};
  
  for (int i = 0; i < 3; i++)
  {  
    for (int j = 0; j < 3; j++)
    {
         if (mat[j][i] % 2 == 0)
         {
             cont += 1;
         }
    }
  }
  
  printf ("A quantidade de pares �: %d", cont);


    return 0;
}
