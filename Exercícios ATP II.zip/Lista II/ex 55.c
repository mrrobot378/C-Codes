/*
 Escreva um programa em C que verifique se uma matriz 3x3  �e
 uma matriz de Cauchy generalizada.
*/

#include <stdio.h>

int ehMatrizCauchy(int matriz[3][3], int x[3], int y[3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (matriz[i][j] != 1 / (x[i] + y[j])) {
                return 0; // Falso
            }
        }
    }
    return 1; // Verdadeiro
}

int main() {
    int matriz[3][3] = {
        {1, 1, 1},
        {1, 1, 1},
        {1, 1, 1}
    };
    
    int x[3] = {1, 2, 3};
    int y[3] = {4, 3, 2};

    if (ehMatrizCauchy(matriz, x, y)) {
        printf("A matriz � uma matriz de Cauchy generalizada.\n");
    } else {
        printf("A matriz n�o � uma matriz de Cauchy generalizada.\n");
    }

    return 0;
}

