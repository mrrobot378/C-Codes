/*
 Escreva um programa em C que realize a rota��o de uma matriz
 quadrada 5x5 no sentido hor�rio.
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main()
{
    srand(time(NULL));
    
     int mat[5][5];
     
     int matP[5][5];
     
    for (int i = 0; i < 5; i++)   
    {
        for (int j = 0; j < 5; j++)
        {
          mat[i][j] = rand () %100;
        }
    }
    

    for (int i = 0; i < 5; i++)   
    {
        for (int j = 0; j < 5; j++)
        {
          matP[i][j] = mat[i][j];
        }
    }
    
    printf ("Matriz modificada:\n");
    for (int i = 0; i < 5; i++)   
    {
        for (int j = 0; j < 5; j++)
        {
          mat[j][i] = matP[4 - i][4 - j];
        }
    }
    
    for (int i = 0; i < 5; i++)   
    {
        for (int j = 0; j < 5; j++)
        {
          printf("%d\t", mat[i][j]);
        }
    printf("\n");    
    }    
    
    
    return 0;
}
