#include <stdio.h>

/*
 Escreva um programa em C que verifique se uma matriz 4x4 �
 uma matriz diagonal.
*/

int main() {
    int mat1[4][4] = {
        {1,0,0,0},
        {0,1,0,0},
        {0,0,1,0},
        {0,0,0,1},
    };
    
    int ehDiagonal = 1;
    
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {   if (i > j)
        {
           if (mat1[i][j] != 0)
           {
               ehDiagonal = 0;
           }
        }
            
        }
    }
    
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {   if (i < j)
        {
           if (mat1[i][j] != 0)
           {
               ehDiagonal = 0;
           }
        }
            
        }
    }
    
    if(ehDiagonal == 0)
    {
        printf("N�o � uma matriz diagonal!");
    }else {
        printf("� uma matriz diagonal!");
    }
    
    return 0;
}

