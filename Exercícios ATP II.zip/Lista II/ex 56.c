/*
 Escreva um programa em C que preencha uma matriz 4x4 com
 n�meros aleat�rios e depois encontre o terceiro maior elemento.
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <limits.h>

int main() {
    srand(time(NULL));
    
    int mat[4][4];
    
    // Preenchendo a matriz com n�meros aleat�rios
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            mat[i][j] = rand() % 100;
        }
    }

    // Exibindo a matriz
    printf("Matriz:\n");
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            printf("%d\t", mat[i][j]);
        }
        printf("\n");
    }

    // Encontrando os tr�s maiores elementos
    int maior = INT_MIN, maior2 = INT_MIN, maior3 = INT_MIN;
    
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (mat[i][j] > maior) {
                maior3 = maior2;
                maior2 = maior;
                maior = mat[i][j];
            } else if (mat[i][j] > maior2) {
                maior3 = maior2;
                maior2 = mat[i][j];
            } else if (mat[i][j] > maior3) {
                maior3 = mat[i][j];
            }
        }
    }

    printf("\nO terceiro maior elemento �: %d\n", maior3);

    return 0;
}

