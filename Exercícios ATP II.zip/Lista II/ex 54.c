/*
 Escreva um programa em C que calcule a soma dos elementos de uma diagonal
 qualquer em uma matriz 4x4
*/

#include <stdio.h>

int main()
{   
    char escolha;
    
    int soma=0;
    
    int mat[4][4]= {
      {1,2,3,4},
      {5,6,7,8},
      {9,10,11,12},
      {13,14,15,16},
    };

   printf("Voc� quer somar qual diagonal?[Digite P para principal e S para secund�ria]?:\n");
   scanf("%c", &escolha);
   if (escolha == 'P')
   {
           for(int j = 0; j < 4; j++)
           {
              soma += mat[j][j];
           }
   }else if (escolha == 'S')
    {
        for(int i = 0; i < 4; i++)
           {
              soma += mat[4 - i][4 - i];
           }
    }
    
    printf("\n\nA soma resultante �: %d", soma);
    return 0;
}
