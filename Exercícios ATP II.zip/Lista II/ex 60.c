/*
  Escreva um programa em C que realize a rota��o de uma matriz
  quadrada 5x5 no sentido anti-hor�rio.
*/

#include <stdio.h>
#include <time.h>

int main (){

  int mat[5][5];
  
  int matR[5][5];
  
  srand (time(0));
  
  for(int i = 0; i < 5; i++) //loop para preencher os valores da matriz
  {
      for(int j = 0; j < 5; j++)
      {
        mat[i][j] = rand () %100;  
      }
  }
  
  printf("Matriz original:\n"); //mostrando a matriz original
  for(int i = 0; i < 5; i++)
  {
      for(int j = 0; j < 5; j++)
      {
        printf("%d\t", mat[i][j]);
      }
    printf("\n");  
  }
  
  for(int i = 0; i < 5; i++) //rotacionando a matriz
  {
      for(int j = 0; j < 5; j++)
      {
        matR[j][i] = mat[i][4 - j];  
      }
  }
  
  printf("\n"); 
  
  printf("Matriz rotacionada:\n");
  for(int i = 0; i < 5; i++)
  {
      for(int j = 0; j < 5; j++)
      {
        printf("%d\t", matR[i][j]);
      }
    printf("\n");  
  }

    return 0;
}

