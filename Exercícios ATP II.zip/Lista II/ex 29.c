/*
  Escreva um programa em C que roteie os elementos de uma matriz
  3x3 em 90 graus no sentido anti-hor�rio.
*/

#include <stdio.h>

int main()
{  
    int mat[3][3] =
    {
        {1,2,3},
        {4,5,6},
        {7,8,9},
    };
    
    int matP[3][3]; //matP = matriz provis�ria que ira receber cada linha
    //para depois fazer a rota��o

    for (int i = 0; i < 3; i++)   
    {
        for (int j = 0; j < 3; j++)
        {
          matP[i][j] = mat[i][j];
        }
    }
    
    printf ("Matriz modificada:\n");
    for (int i = 0; i < 3; i++)   
    {
        for (int j = 0; j < 3; j++)
        {
          mat[i][j] = matP[j][2 - i];
        }
    }
    
    for (int i = 0; i < 3; i++)   
    {
        for (int j = 0; j < 3; j++)
        {
          printf("%d\t", mat[i][j]);
        }
    printf("\n");    
    }    
    
    
    return 0;
}

