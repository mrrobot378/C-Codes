#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//ordenada de maneira crescente

// Fun��o para preencher e ordenar a matriz
void preencherEOrdenarMatriz(int matriz[4][4]) {
    srand(time(NULL)); // Define a semente para n�meros aleat�rios
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            matriz[i][j] = rand() % 100; // Gera n�meros aleat�rios entre 0 e 99
        }
        // Ordena a linha ap�s preench�-la
        for (int k = 0; k < 3; k++) {
            for (int l = 0; l < 3 - k; l++) {
                if (matriz[i][l] > matriz[i][l + 1]) {
                    int temp = matriz[i][l];
                    matriz[i][l] = matriz[i][l + 1];
                    matriz[i][l + 1] = temp;
                }
            }
        }
    }
}

// Fun��o para imprimir a matriz
void imprimirMatriz(int matriz[4][4]) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            printf("%d\t", matriz[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int matriz[4][4];

    preencherEOrdenarMatriz(matriz);

    printf("Matriz preenchida e ordenada:\n");
    imprimirMatriz(matriz);

    return 0;
}

