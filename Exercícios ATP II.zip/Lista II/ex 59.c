/*
  Escreva um programa em C que verifique se uma matriz 2x2  �e
 uma matriz de reflex�o.
*/

#include <stdio.h>

int ehReflexiva(float matriz[2][2]) {
    // Calcula o determinante
    float det = matriz[0][0] * matriz[1][1] - matriz[0][1] * matriz[1][0];
    
    // Verifica se o determinante � -1
    if (det != -1) {
        return 0;
    }

    // Calcula R^2
    float r2[2][2];
    r2[0][0] = matriz[0][0] * matriz[0][0] + matriz[0][1] * matriz[1][0];
    r2[0][1] = matriz[0][0] * matriz[0][1] + matriz[0][1] * matriz[1][1];
    r2[1][0] = matriz[1][0] * matriz[0][0] + matriz[1][1] * matriz[1][0];
    r2[1][1] = matriz[1][0] * matriz[0][1] + matriz[1][1] * matriz[1][1];

    // Verifica se R^2 � a matriz identidade
    if (r2[0][0] == 1 && r2[0][1] == 0 && r2[1][0] == 0 && r2[1][1] == 1) {
        return 1; // � uma matriz de reflex�o
    }

    return 0; // N�o � uma matriz de reflex�o
}

int main() {
    float matriz[2][2];

    printf("Digite os elementos da matriz 2x2:\n");
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            scanf("%f", &matriz[i][j]);
        }
    }

    if (ehReflexiva(matriz)) {
        printf("A matriz � uma matriz de reflex�o.\n");
    } else {
        printf("A matriz n�o � uma matriz de reflex�o.\n");
    }

    return 0;
}

