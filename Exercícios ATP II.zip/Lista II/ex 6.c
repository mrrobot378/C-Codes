#include <stdio.h>

/*
Escreva um programa em C que calcule a diagonal principal de
uma matriz 5x5.
*/
 
 int soma = 0;

int main() {
    int mat[5][5] = {
        {1, 2, 3, 4, 5},
        {6, 7, 8, 9, 10},
        {11, 12, 13, 14, 15},
        {16, 17, 18, 19, 20},
        {21, 22, 23, 24, 25}
    };

    printf("Diagonal Principal:");
    for (int i = 0; i < 5; i++) {
        printf ("\n%d", mat[i][i]);
        soma += mat[i][i];
    }
    printf("\nSoma da Diagonal Principal: %d", soma);

    return 0;
}


