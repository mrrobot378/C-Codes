/*
 Escreva um programa em C que encontre o menor elemento em
 uma matriz 5x5.
*/

#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

int main()
{  
    srand (time(0));
     
    int menor = RAND_MAX; 
          
     int mat[5][5];

    for (int i = 0; i < 5; i++) //preenchendo com valores ale�torios
    {
        for (int j = 0; j < 5; j++)
        {
            mat[i][j] = rand () %100;
        }
    }
    
    for (int i = 0; i < 5; i++) //mostrando a matriz para ter certeza que � o menor
    {
        for (int j = 0; j < 5; j++)
        {
            printf("%d\t", mat[i][j]);
        }
    printf("\n");    
    }
    
    for (int i = 0; i < 5; i++) //verificando cada posi��o e atribuindo a "menor" se for menor que o anterior
    {
        for (int j = 0; j < 5; j++)
        {
            if (mat[i][j] < menor)
            {
                menor = mat[i][j];
            }
        }
    }

    printf("O menor elemento �: %d", menor);

    return 0;
}
