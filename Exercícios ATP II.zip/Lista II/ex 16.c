#include <stdio.h>

// Fun��o para verificar se um n�mero � primo
int ehPrimo(int num) {
    if (num <= 1) return 0; // N�meros menores ou iguais a 1 n�o s�o primos
    for (int i = 2; i <= num / 2; i++) {
        if (num % i == 0) return 0; // Se for divis�vel por i, n�o � primo
    }
    return 1; // Se n�o for divis�vel por nenhum i, � primo
}

int main() {
    int matriz[5][5]; // Declara��o da matriz 5x5
    int num = 2; // Primeiro n�mero primo
    int linha, coluna;

    // Preencher a matriz com n�meros primos
    for (linha = 0; linha < 5; linha++) {
        for (coluna = 0; coluna < 5; coluna++) {
            while (!ehPrimo(num)) { // Encontrar o pr�ximo n�mero primo
                num++;
            }
            matriz[linha][coluna] = num; // Atribuir o n�mero primo � matriz
            num++; // Passar para o pr�ximo n�mero
        }
    }

    // Imprimir a matriz
    printf("Matriz 5x5 preenchida com n�meros primos:\n");
    for (linha = 0; linha < 5; linha++) {
        for (coluna = 0; coluna < 5; coluna++) {
            printf("%d\t", matriz[linha][coluna]);
        }
        printf("\n");
    }

    return 0;
}

