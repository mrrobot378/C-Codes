/*
 Escreva um programa em C que verifique se uma matriz 2x2  �e
 uma matriz de reflex�o.
*/

#include <stdio.h>

int main()
{  
    int cond = 0; //cond = condi��es a serem satisfeitas para 
    //considerar se � uma matriz de reflex�o
    
    int mat[2][2] = {
        {2,1},
        {1,-2},
    };

    if (mat[0][0] == -mat[1][1])
    {
        cond = 1;
    }
    
    if (mat[0][1] == mat[1][0])
    {
        cond += 1;
    }

    if (cond == 2)
    {
        printf("� uma matriz de reflex�o!");
    }else if (cond != 2)
    {
        printf("N�o � uma matriz de reflex�o!");
    }

    return 0;
}
