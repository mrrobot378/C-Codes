/*
 Escreva um programa em C que preencha uma matriz 5x5 com
 n�meros aleat�rios e depois encontre o segundo maior elemento.
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <limits.h>

int main()
{   srand(time(NULL));
   
    int maior = INT_MIN;
    
    int maior2 = INT_MIN;
    
    int mat[5][5];
    
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            mat[i][j] = rand () %100;
        }
    }

    printf("Matriz:\n");
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            printf("%d\t",mat[i][j]);
        }
    printf("\n");    
    }
    
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            if (mat[i][j] > maior)
            {
                maior = mat[i][j];
            }
        }
    }
    
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            if (mat[i][j] > maior2 && mat[i][j] < maior)
            {
                maior2 = mat[i][j];
            }
        }
    }

    printf("\nO segundo maior elemento �: %d", maior2);

    return 0;
}
