#include <stdio.h>

// Fun��o para verificar se a matriz � sim�trica
int ehSim(float matriz[2][2]) {
    return (matriz[0][1] == matriz[1][0]);
}

// Fun��o para verificar se a matriz � ortogonal
int ehOrt(float matriz[2][2]) {
    float identidade[2][2] = {{1, 0}, {0, 1}};
    float produto[2][2];

    // Calcula o produto da matriz por sua transposta
    produto[0][0] = matriz[0][0] * matriz[0][0] + matriz[0][1] * matriz[0][1];
    produto[0][1] = matriz[0][0] * matriz[1][0] + matriz[0][1] * matriz[1][1];
    produto[1][0] = matriz[1][0] * matriz[0][0] + matriz[1][1] * matriz[0][1];
    produto[1][1] = matriz[1][0] * matriz[1][0] + matriz[1][1] * matriz[1][1];

    // Verifica se o produto � a matriz identidade
    return (produto[0][0] == identidade[0][0] && produto[0][1] == identidade[0][1] &&
            produto[1][0] == identidade[1][0] && produto[1][1] == identidade[1][1]);
}

int main() {
    float matriz[2][2];

    // Entrada da matriz 2x2
    printf("Digite os elementos da matriz 2x2:\n");
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            scanf("%f", &matriz[i][j]);
        }
    }

    // Verifica se a matriz � de Householder
    if (ehSim(matriz) && ehOrt(matriz)) {
        printf("A matriz � uma matriz de Householder.\n");
    } else {
        printf("A matriz n�o � uma matriz de Householder.\n");
    }

    return 0;
}

