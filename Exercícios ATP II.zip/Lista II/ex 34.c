#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

/*
 Escreva um programa em C que preencha uma matriz 3x3 com
 n�meros primos e depois substitua os n�meros primos por 1.
*/

// Fun��o para verificar se um n�mero � primo
int ehPrimo(int num) {
    if (num <= 1) return 0;
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) return 0;
    }
    return 1;
}

int main()
{  
    int mat[3][3] = {
        {2, 3, 7},
        {11, 13, 17},
        {19, 23, 5},
    };
    
    for (int i = 0; i < 3; i++) 
    {
        for (int j = 0; j < 3; j++)
        {
            if (ehPrimo(mat[i][j])) // Verifica se o n�mero � primo
            {
                mat[i][j] = 1; // Substitui por 1
            }
        }
    }

    // Imprime a matriz para verificar a substitui��o
    for (int i = 0; i < 3; i++) 
    {
        for (int j = 0; j < 3; j++)
        {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }

    return 0;
}

